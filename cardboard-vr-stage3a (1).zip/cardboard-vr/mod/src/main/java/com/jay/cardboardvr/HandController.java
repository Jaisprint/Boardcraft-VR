package com.jay.cardboardvr;

import net.minecraft.client.Minecraft;

/**
 * 3DoF controller -> Minecraft hand (UNTESTED).
 *
 * Packet from the gyro app ("HC1,qw,qx,qy,qz,ax,ay,az,jx,jy,btn"):
 *   q  = controller orientation, sensor frame -> world (Z up, arbitrary heading), sensor: +X forward, +Y left, +Z up
 *   a  = linear acceleration in that same world frame, gravity removed, m/s^2
 *   jx/jy = stick -1..1, btn = bit0 stick press, bit1 trigger 1, bit2 trigger 2, bit3 calibrate (long press)
 *
 * Hand = shoulder pivot + two-link arm model driven by the controller's rotation, plus a small push offset
 * from the accelerometer (damped, locked while the controller is still, clamped to arm reach).
 * Calibrate: points the controller's current heading at the player's current heading.
 */
public final class HandController {
    private static final Object LOCK = new Object();

    // latest state
    private static float qw = 1, qx, qy, qz;
    private static float pqw = 1, pqx, pqy, pqz;
    private static float jx, jy;
    private static int btn, lastBtn;
    private static volatile long lastPacketMs;
    private static long lastNs;
    private static boolean calibrated;
    private static double psi;                       // yaw offset (radians) controller world -> Minecraft world
    private static final float[] off = new float[3]; // push offset, Minecraft world metres
    private static final float[] vel = new float[3];
    private static float stillTime;
    private static final float[] cur = new float[3];   // hand position relative to the shoulder (arm vector + push), what we actually show
    private static boolean curInit;
    private static float trans;                        // 0..1 "the hand is really moving" score from the accelerometer
    private static float lastHfx = 0f, lastHfz = 1f;

    // arm model (metres)
    private static final float L1 = 0.30f, L2 = 0.32f, SHOULDER_SIDE = 0.30f, SHOULDER_DROP = 0.22f;
    private static final float ELBOW_FOLLOW = 0.5f;

    private HandController() {}

    public static boolean active() { return System.currentTimeMillis() - lastPacketMs < 600; }
    public static float stickX() { return jx; }
    public static float stickY() { return jy; }
    public static int buttons() { return btn; }

    public static void requestCalibrate() {
        synchronized (LOCK) { calibrateLocked(); }
    }

    public static void onPacket(String msg) {
        try {
            String[] p = msg.trim().split(",");
            if (p.length < 11 || !p[0].equals("HC1")) return;
            float nqw = Float.parseFloat(p[1]), nqx = Float.parseFloat(p[2]), nqy = Float.parseFloat(p[3]), nqz = Float.parseFloat(p[4]);
            float ax = Float.parseFloat(p[5]), ay = Float.parseFloat(p[6]), az = Float.parseFloat(p[7]);
            float njx = Float.parseFloat(p[8]), njy = Float.parseFloat(p[9]);
            int nbtn = Integer.parseInt(p[10].trim());

            VrConfig c = VrConfig.I;
            long nowNs = System.nanoTime();
            synchronized (LOCK) {
                float dt = lastNs == 0 ? 0.02f : (nowNs - lastNs) * 1e-9f;
                lastNs = nowNs;
                if (dt < 0.002f) dt = 0.002f;
                if (dt > 0.05f) dt = 0.05f;

                // angular speed from the change between quaternions (deg/s)
                double dot = Math.abs(nqw * qw + nqx * qx + nqy * qy + nqz * qz);
                double ang = 2.0 * Math.acos(Math.min(1.0, dot));
                float wDeg = (float) Math.toDegrees(ang / dt);

                pqw = qw; pqx = qx; pqy = qy; pqz = qz;
                qw = nqw; qx = nqx; qy = nqy; qz = nqz;
                jx = njx; jy = njy;
                lastBtn = btn;
                btn = nbtn;
                lastPacketMs = System.currentTimeMillis();

                if (!calibrated || ((btn & 8) != 0 && (lastBtn & 8) == 0)) calibrateLocked();

                float[] a = toMc(ax, ay, az);
                float amag = (float) Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
                if (!c.handMotion) {
                    off[0] = off[1] = off[2] = 0;
                    vel[0] = vel[1] = vel[2] = 0;
                    updateCur(c, amag, dt);
                    return;
                }
                boolean quiet = amag < c.handDeadzone * 1.5f && wDeg < 6f;
                stillTime = quiet ? stillTime + dt : 0f;

                if (stillTime > 0.12f) {
                    vel[0] = vel[1] = vel[2] = 0;                     // hold-still lock
                } else {
                    float k = 0f;                                      // soft deadzone on acceleration
                    if (amag > c.handDeadzone) k = (amag - c.handDeadzone) / amag;
                    float damp = (float) Math.exp(-c.handFriction * dt);
                    for (int i = 0; i < 3; i++) {
                        vel[i] = (vel[i] + a[i] * k * dt) * damp;
                        off[i] += vel[i] * dt;
                    }
                }
                if (c.handReturn > 0f) {
                    float r = (float) Math.exp(-c.handReturn * dt);
                    for (int i = 0; i < 3; i++) off[i] *= r;
                }
                float len = (float) Math.sqrt(off[0] * off[0] + off[1] * off[1] + off[2] * off[2]);
                if (len > c.handReach) {
                    float s = c.handReach / len;
                    for (int i = 0; i < 3; i++) { off[i] *= s; vel[i] = 0; }
                }
                updateCur(c, amag, dt);
            }
        } catch (Exception ignored) {
        }
    }

    /** Hand position relative to the shoulder from the arm model (needs only the controller orientation + push offset). */
    private static float[] armVec() {
        float r00 = 1 - 2 * (qy * qy + qz * qz), r10 = 2 * (qx * qy + qw * qz), r20 = 2 * (qx * qz - qw * qy);
        float[] f = toMc(r00, r10, r20);
        float hl = (float) Math.sqrt(f[0] * f[0] + f[2] * f[2]);
        if (hl > 0.05f) { lastHfx = f[0] / hl; lastHfz = f[2] / hl; }
        double e = Math.asin(Math.max(-1f, Math.min(1f, f[1])));
        double alpha = Math.max(-0.6, Math.min(1.2, ELBOW_FOLLOW * e));
        float sa = (float) Math.sin(alpha), ca = (float) Math.cos(alpha);
        return new float[]{
            L1 * lastHfx * sa + L2 * f[0] + off[0],
            -L1 * ca + L2 * f[1] + off[1],
            L1 * lastHfz * sa + L2 * f[2] + off[2]};
    }

    /**
     * Real-motion gate: the arm model is only a guess made from rotation, so the shown hand position only follows it
     * while the accelerometer says the controller is really moving. Pure rotation in place (no acceleration) rotates
     * the hand but does not move it; when real motion stops, the hand stays where it ended up.
     */
    private static void updateCur(VrConfig c, float amag, float dt) {
        float[] av = armVec();
        if (!curInit || !c.handGate) {
            cur[0] = av[0]; cur[1] = av[1]; cur[2] = av[2];
            curInit = true;
            trans = 1f;
            return;
        }
        float sNow = Math.max(0f, Math.min(1f, (amag - c.handDeadzone) / 1.5f));
        float tau = sNow > trans ? 0.04f : 0.25f;                 // react fast, let go slowly so the swing finishes
        trans += (sNow - trans) * (1f - (float) Math.exp(-dt / tau));
        float k = 1f - (float) Math.exp(-30f * trans * dt);
        for (int i = 0; i < 3; i++) cur[i] += (av[i] - cur[i]) * k;
    }

    private static void calibrateLocked() {
        double fx = 1 - 2 * (qy * qy + qz * qz), fy = 2 * (qx * qy + qw * qz);
        double hc = Math.atan2(fy, fx);
        float yaw = 0f;
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) yaw = mc.player.getYRot();
        } catch (Throwable ignored) {
        }
        psi = -Math.toRadians(yaw) - Math.PI / 2 - hc;
        calibrated = true;
        off[0] = off[1] = off[2] = 0;
        vel[0] = vel[1] = vel[2] = 0;
        curInit = false;   // hand snaps back to the arm-model pose
    }

    /** controller world (East, North, Up) -> Minecraft world (x east, y up, z south), with the calibration yaw. */
    private static float[] toMc(float x, float y, float z) {
        double c = Math.cos(psi), s = Math.sin(psi);
        float ex = (float) (x * c - y * s), ey = (float) (x * s + y * c);
        return new float[]{ex, z, -ey};
    }

    /**
     * Pose for the main hand in camera space, or null when there is no controller data.
     * Returns {tx, ty, tz, qx, qy, qz, qw}: translate(t), rotate(q), then translate(-rest) around the vanilla hand.
     * side = +1 right hand, -1 left hand.
     */
    public static float[] pose(float yawDeg, float pitchDeg, float side) {
        if (!active()) return null;
        float cw, cx, cy, cz;
        float[] o = new float[3];
        double ps;
        synchronized (LOCK) {
            cw = qw; cx = qx; cy = qy; cz = qz;
            o[0] = cur[0]; o[1] = cur[1]; o[2] = cur[2];
            ps = psi;
        }
        // rotation matrix of the quaternion (sensor -> controller world), columns = sensor axes in the world
        float r00 = 1 - 2 * (cy * cy + cz * cz), r01 = 2 * (cx * cy - cw * cz), r02 = 2 * (cx * cz + cw * cy);
        float r10 = 2 * (cx * cy + cw * cz), r11 = 1 - 2 * (cx * cx + cz * cz), r12 = 2 * (cy * cz - cw * cx);
        float r20 = 2 * (cx * cz - cw * cy), r21 = 2 * (cy * cz + cw * cx), r22 = 1 - 2 * (cx * cx + cy * cy);
        float[] ax0 = toMc(r00, r10, r20);   // forward
        float[] ax1 = toMc(r01, r11, r21);   // left
        float[] ax2 = toMc(r02, r12, r22);   // up

        // arm model
        float d0 = ax0[0], d1 = ax0[1], d2 = ax0[2];
        double yaw = Math.toRadians(yawDeg), pitch = Math.toRadians(pitchDeg);
        float hl = (float) Math.sqrt(d0 * d0 + d2 * d2);
        float hfx, hfz;
        if (hl > 0.05f) { hfx = d0 / hl; hfz = d2 / hl; }
        else { hfx = (float) -Math.sin(yaw); hfz = (float) Math.cos(yaw); }
        double e = Math.asin(Math.max(-1f, Math.min(1f, d1)));
        double alpha = Math.max(-0.6, Math.min(1.2, ELBOW_FOLLOW * e));
        float sa = (float) Math.sin(alpha), ca = (float) Math.cos(alpha);

        float rgx = (float) -Math.cos(yaw), rgz = (float) -Math.sin(yaw);          // horizontal right
        float shx = side * SHOULDER_SIDE * rgx, shy = -SHOULDER_DROP, shz = side * SHOULDER_SIDE * rgz;
        float elx = shx + L1 * hfx * sa, ely = shy - L1 * ca, elz = shz + L1 * hfz * sa;
        float hx = shx + o[0], hy = shy + o[1], hz = shz + o[2];   // o = arm vector from the shoulder (gated)

        // camera basis in the world
        float fx = (float) (-Math.sin(yaw) * Math.cos(pitch)), fy = (float) -Math.sin(pitch), fz = (float) (Math.cos(yaw) * Math.cos(pitch));
        float rx = rgx, ry = 0f, rz = rgz;
        float ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;

        // hand position in camera space (x right, y up, z backward)
        float px = hx * rx + hy * ry + hz * rz, py = hx * ux + hy * uy + hz * uz, pz = -(hx * fx + hy * fy + hz * fz);

        // neutral (level, pointing forward) in camera space, so the neutral pose matches vanilla's hand spot
        float nx = side * SHOULDER_SIDE, ny = -(SHOULDER_DROP + L1), nz = -L2;
        float restX = side * 0.60f, restY = -0.56f, restZ = -0.72f;
        float tx = px - nx + restX, ty = py - ny + restY, tz = pz - nz + restZ;

        // H = C * Rh (controller axes -> camera space)
        float[][] ax = {ax0, ax1, ax2};
        float[][] H = new float[3][3];
        for (int j = 0; j < 3; j++) {
            float[] v = ax[j];
            H[0][j] = v[0] * rx + v[1] * ry + v[2] * rz;
            H[1][j] = v[0] * ux + v[1] * uy + v[2] * uz;
            H[2][j] = -(v[0] * fx + v[1] * fy + v[2] * fz);
        }
        // Rc2cam rows: [0,-1,0],[0,0,1],[-1,0,0]  ->  D = H * Rc2cam^T
        float[][] T = {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}};   // Rc2cam^T
        float[][] D = new float[3][3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                D[i][j] = H[i][0] * T[0][j] + H[i][1] * T[1][j] + H[i][2] * T[2][j];

        float[] q = matToQuat(D);
        return new float[]{tx, ty, tz, q[0], q[1], q[2], q[3]};
    }

    /** row-major 3x3 rotation matrix -> {x, y, z, w} */
    private static float[] matToQuat(float[][] m) {
        float tr = m[0][0] + m[1][1] + m[2][2];
        float x, y, z, w, s;
        if (tr > 0f) {
            s = (float) Math.sqrt(tr + 1f) * 2f;
            w = 0.25f * s; x = (m[2][1] - m[1][2]) / s; y = (m[0][2] - m[2][0]) / s; z = (m[1][0] - m[0][1]) / s;
        } else if (m[0][0] > m[1][1] && m[0][0] > m[2][2]) {
            s = (float) Math.sqrt(1f + m[0][0] - m[1][1] - m[2][2]) * 2f;
            w = (m[2][1] - m[1][2]) / s; x = 0.25f * s; y = (m[0][1] + m[1][0]) / s; z = (m[0][2] + m[2][0]) / s;
        } else if (m[1][1] > m[2][2]) {
            s = (float) Math.sqrt(1f + m[1][1] - m[0][0] - m[2][2]) * 2f;
            w = (m[0][2] - m[2][0]) / s; x = (m[0][1] + m[1][0]) / s; y = 0.25f * s; z = (m[1][2] + m[2][1]) / s;
        } else {
            s = (float) Math.sqrt(1f + m[2][2] - m[0][0] - m[1][1]) * 2f;
            w = (m[1][0] - m[0][1]) / s; x = (m[0][2] + m[2][0]) / s; y = (m[1][2] + m[2][1]) / s; z = 0.25f * s;
        }
        float n = (float) Math.sqrt(x * x + y * y + z * z + w * w);
        if (n < 1e-6f) return new float[]{0, 0, 0, 1};
        return new float[]{x / n, y / n, z / n, w / n};
    }
}
