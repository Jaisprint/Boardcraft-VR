package com.jay.cardboardvr.mixin;

import com.jay.cardboardvr.HandController;
import com.jay.cardboardvr.VrConfig;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FirstPersonHandsAndItemsRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.FirstPersonHandsAndItemsRenderState;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Moves the first-person main hand (arm + held item) to where the controller's arm model says it is.
 * Method signature copied from Vivecraft's 26.3 branch. HEAD pushes a transform, RETURN pops it.
 */
@Mixin(FirstPersonHandsAndItemsRenderer.class)
public abstract class FirstPersonHandMixin {
    private static boolean cardboardvr$pushed;
    private static HumanoidArm cardboardvr$arm = HumanoidArm.RIGHT;

    @Shadow
    protected abstract void renderPlayerArm(PoseStack poseStack, SubmitNodeCollector collector, int combinedLight,
                                            float equippedProgress, float swingProgress, HumanoidArm side, PlayerRenderState playerState);

    @Inject(method = "submitArmWithItem", at = @At("HEAD"), require = 0)
    private void cardboardvr$handHead(
        PlayerRenderState playerState, FirstPersonHandsAndItemsRenderState state, float partialTick, float pitch,
        InteractionHand hand, float swingProgress, ItemStack itemStack, float equippedProgress, PoseStack poseStack,
        SubmitNodeCollector collector, int combinedLight, CallbackInfo ci)
    {
        cardboardvr$pushed = false;
        try {
            if (hand != InteractionHand.MAIN_HAND || !VrConfig.I.handEnabled || !HandController.active()) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;
            float side = 1f;
            try { side = mc.options.mainHand().get() == HumanoidArm.RIGHT ? 1f : -1f; } catch (Throwable ignored) { }
            float[] p = HandController.pose(mc.player.getYRot(), mc.player.getXRot(), side);
            if (p == null) return;
            float restX = side * 0.60f, restY = -0.56f, restZ = -0.72f;
            poseStack.pushPose();
            poseStack.translate(p[0], p[1], p[2]);
            poseStack.mulPose(new Quaternionf(p[3], p[4], p[5], p[6]));
            poseStack.translate(-restX, -restY, -restZ);
            cardboardvr$arm = side > 0f ? HumanoidArm.RIGHT : HumanoidArm.LEFT;
            cardboardvr$pushed = true;
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "submitArmWithItem", at = @At("RETURN"), require = 0)
    private void cardboardvr$handReturn(
        PlayerRenderState playerState, FirstPersonHandsAndItemsRenderState state, float partialTick, float pitch,
        InteractionHand hand, float swingProgress, ItemStack itemStack, float equippedProgress, PoseStack poseStack,
        SubmitNodeCollector collector, int combinedLight, CallbackInfo ci)
    {
        if (cardboardvr$pushed) {
            cardboardvr$pushed = false;
            // VR style: the arm stays visible with the item at the palm (vanilla hides the arm when an item is held)
            if (VrConfig.I.handShowArm && itemStack != null && !itemStack.isEmpty()) {
                try {
                    poseStack.pushPose();
                    renderPlayerArm(poseStack, collector, combinedLight, 0f, 0f, cardboardvr$arm, playerState);
                    poseStack.popPose();
                } catch (Throwable ignored) { }
            }
            try { poseStack.popPose(); } catch (Throwable ignored) { }
        }
    }
}
