package com.jay.cardboardvr.mixin;

import com.jay.cardboardvr.ScreenCompat;
import com.jay.cardboardvr.VrSettingsScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds a "VR" button to the pause menu, to the right of the main button column (next to Options / Mod Menu row). */
@Mixin(PauseScreen.class)
public abstract class PauseScreenMixin extends Screen {
    protected PauseScreenMixin(Component title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"), require = 0)
    private void cardboardvr$addVrButton(CallbackInfo ci) {
        int maxRight = this.width / 2 + 102;
        int y = this.height / 4 + 72;
        String options = Component.translatable("menu.options").getString();
        for (var ch : this.children()) {
            if (ch instanceof AbstractWidget w) {
                maxRight = Math.max(maxRight, w.getX() + w.getWidth());
                String m = w.getMessage().getString();
                if (m.contains("Mod") || m.equals(options)) y = w.getY();
            }
        }
        int bw = 70;
        int x = maxRight + 4;
        if (x + bw > this.width) x = this.width - bw - 2;
        this.addRenderableWidget(Button.builder(Component.literal("VR Settings"),
                b -> ScreenCompat.open(Minecraft.getInstance(), new VrSettingsScreen(this)))
                .bounds(x, y, bw, 20).build());
    }
}
