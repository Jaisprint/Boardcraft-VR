package com.jay.cardboardvr.mixin;

import com.jay.cardboardvr.FloatingMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Makes the menu panorama follow your head: replaces the pitch and yaw that the panorama is drawn with while
 * VR menus + head tracking are active. require = 0 everywhere: if a Minecraft update changes CubeMap.render
 * the hook silently does nothing (the settings screen then shows "Panorama: waiting") and the vanilla spin stays.
 */
@Mixin(targets = "net.minecraft.client.renderer.CubeMap")
public abstract class PanoramaMixin {
    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private float cardboardvr$pitch(float pitch) {
        return FloatingMenu.panoPitch(pitch);
    }

    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
    private float cardboardvr$yaw(float yaw) {
        return FloatingMenu.panoYaw(yaw);
    }
}
