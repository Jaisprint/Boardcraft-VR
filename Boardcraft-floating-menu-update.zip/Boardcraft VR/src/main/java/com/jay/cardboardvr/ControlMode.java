package com.jay.cardboardvr;

/**
 * Controller modes shown in the VR settings. Only LOCKED_CROSSHAIR does anything today: the crosshair stays
 * in the middle of the view and tapping the screen touches. The other modes are placeholders (dummies) for
 * the future 6DoF controller work; picking one saves the choice but input still behaves like Locked Crosshair.
 */
public enum ControlMode {
    LOCKED_CROSSHAIR("Locked Crosshair", true),
    ESP32("Custom ESP32 Controller", false),
    GEARVR("GearVR Controller", false),
    DAYDREAM("Daydream Controller", false),
    GALAXY_XR("Samsung Galaxy XR Controller", false),
    JOYCONS("Nintendo Joy-Cons", false);

    public final String label;
    /** False = dummy, not implemented yet. */
    public final boolean working;

    ControlMode(String label, boolean working) {
        this.label = label;
        this.working = working;
    }

    /** The mode the player picked (may be a dummy). */
    public static ControlMode selected() {
        int i = VrConfig.I.controlMode;
        ControlMode[] v = values();
        return (i < 0 || i >= v.length) ? LOCKED_CROSSHAIR : v[i];
    }

    /** The mode that really drives input: dummies fall back to Locked Crosshair. */
    public static ControlMode effective() {
        ControlMode m = selected();
        return m.working ? m : LOCKED_CROSSHAIR;
    }
}
