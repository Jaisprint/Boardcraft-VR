package com.jay.cardboardvr;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;

import java.util.ArrayList;
import java.util.List;

/**
 * Floating main menu. The title panorama is the 3D background (it follows your head, see PanoramaMixin) and the
 * menu floats in front of it: a panel behind the main buttons, the buttons on top, the small icon buttons even
 * nearer. Every frame the layers slide by different amounts as you turn your head (parallax) plus a slow bob.
 * Widgets are really moved with setPosition, so touch / click always hits what you see.
 * Only active while VR mode is ON (menus too) and "Floating menus" is enabled.
 */
public class FloatingMenu {
    private static final class Item {
        final AbstractWidget w;
        final int bx, by;
        final float depth, phase;
        Item(AbstractWidget w, float depth, float phase) {
            this.w = w;
            this.bx = w.getX();
            this.by = w.getY();
            this.depth = depth;
            this.phase = phase;
        }
    }

    static final float PX_PER_DEG = 1.0f;
    static final float MAX_PX = 24f;
    static final float DEPTH_PANEL = 0.7f, DEPTH_MAIN = 1.0f, DEPTH_SIDE = 1.4f;

    private static Screen screen;
    private static final List<Item> items = new ArrayList<>();
    private static float ox, oy;
    /** Last time the panorama hook ran with head tracking (shown in settings so a missing hook is visible). */
    public static volatile long panoHitMs = 0;

    public static boolean wanted() {
        VrConfig c = VrConfig.I;
        return c.floatingMenus && c.vrMode == 1;
    }

    /** Called by TitleScreenMixin after it has built (and reordered) the widgets. */
    public static void set(Screen s, AbstractWidget panel, List<AbstractWidget> mains, List<AbstractWidget> sides) {
        clear();
        screen = s;
        if (panel != null) items.add(new Item(panel, DEPTH_PANEL, 0f));
        for (AbstractWidget w : mains) items.add(new Item(w, DEPTH_MAIN, 0f));
        for (AbstractWidget w : sides) items.add(new Item(w, DEPTH_SIDE, 1.7f));
        ox = 0f;
        oy = 0f;
    }

    public static void clear() {
        screen = null;
        items.clear();
    }

    private static float wrap(float d) {
        while (d > 180f) d -= 360f;
        while (d < -180f) d += 360f;
        return d;
    }

    private static float clamp(float v) {
        return Math.max(-MAX_PX, Math.min(MAX_PX, v));
    }

    /** Render thread, start of every frame. */
    public static void frame(Minecraft mc) {
        if (screen == null) return;
        if (ScreenCompat.current(mc) != screen || !wanted()) {
            // left the title screen (or turned off): put everything back where vanilla had it
            for (Item it : items) it.w.setPosition(it.bx, it.by);
            clear();
            return;
        }
        float tx = 0f, ty = 0f;
        GyroReceiver g = GyroReceiver.I;
        if (g.menuPoseActive()) {
            tx = clamp(-wrap(g.menuYaw()) * PX_PER_DEG);
            ty = clamp(-g.menuPitch() * PX_PER_DEG);
        }
        ox += (tx - ox) * 0.25f;
        oy += (ty - oy) * 0.25f;
        double t = System.nanoTime() / 1.0e9;
        for (Item it : items) {
            float bobX = (float) Math.sin(t * 0.9 + it.phase) * 1.0f;
            float bobY = (float) Math.sin(t * 1.3 + it.phase) * 2.0f;
            int x = it.bx + Math.round((ox + bobX) * it.depth);
            int y = it.by + Math.round((oy + bobY) * it.depth);
            it.w.setPosition(x, y);
        }
    }

    // ---- panorama (3D background) ----

    public static boolean panoActive(Minecraft mc) {
        return wanted() && mc.player == null && GyroReceiver.I.menuPoseActive();
    }

    public static float panoYaw(float vanilla) {
        Minecraft mc = Minecraft.getInstance();
        if (!panoActive(mc)) return vanilla;
        panoHitMs = System.currentTimeMillis();
        float y = GyroReceiver.I.menuYaw();
        return VrConfig.I.panoInvertYaw ? -y : y;
    }

    public static float panoPitch(float vanilla) {
        Minecraft mc = Minecraft.getInstance();
        if (!panoActive(mc)) return vanilla;
        float p = GyroReceiver.I.menuPitch();
        return VrConfig.I.panoInvertPitch ? -p : p;
    }

    public static String panoStatus() {
        if (!wanted()) return "Needs VR mode ON";
        if (!GyroReceiver.I.isActive()) return "Panorama: no gyro";
        return System.currentTimeMillis() - panoHitMs < 1500 ? "Panorama: tracked" : "Panorama: waiting";
    }
}
