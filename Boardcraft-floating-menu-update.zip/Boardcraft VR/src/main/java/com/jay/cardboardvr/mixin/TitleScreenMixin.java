package com.jay.cardboardvr.mixin;

import com.jay.cardboardvr.FloatingMenu;
import com.jay.cardboardvr.Icons;
import com.jay.cardboardvr.ScreenCompat;
import com.jay.cardboardvr.VrSettingsScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.SpriteIconButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * One icon button on the title screen: grey cardboard = VR off, green = VR on. Opens the VR settings.
 * With VR mode ON and "Floating menus" enabled the main buttons also get a panel behind them and are handed
 * to FloatingMenu, which makes the menu float in front of the head-tracked panorama.
 */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Component title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void cardboardvr$addButtons(CallbackInfo ci) {
        int x = this.width / 2 + 104, y = this.height / 4 + 48;
        this.addRenderableWidget(Icons.button(Icons.sprite(false), Component.literal("VR Settings"),
                b -> ScreenCompat.open(Minecraft.getInstance(), new VrSettingsScreen(this)), x, y));

        cardboardvr$floatify();
    }

    private void cardboardvr$floatify() {
        FloatingMenu.clear();
        if (!FloatingMenu.wanted()) return;
        List<AbstractWidget> mains = new ArrayList<>(), sides = new ArrayList<>();
        for (var ch : this.children()) {
            if (ch instanceof AbstractWidget w) {
                if (w.getClass() == Button.class) mains.add(w);          // Singleplayer, Multiplayer, Realms, Options, Quit
                else if (w instanceof SpriteIconButton) sides.add(w);    // language, accessibility, our VR icon
            }
        }
        if (mains.isEmpty()) return;
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
        for (AbstractWidget w : mains) {
            minX = Math.min(minX, w.getX());
            minY = Math.min(minY, w.getY());
            maxX = Math.max(maxX, w.getX() + w.getWidth());
            maxY = Math.max(maxY, w.getY() + w.getHeight());
        }
        int pad = 4;
        Button panel = Button.builder(Component.literal(""), b -> {})
                .bounds(minX - pad, minY - pad, (maxX - minX) + pad * 2, (maxY - minY) + pad * 2).build();
        panel.active = false;
        // the panel must be drawn first, so take the buttons out and put them back after it
        for (AbstractWidget w : mains) this.removeWidget(w);
        this.addRenderableWidget(panel);
        for (AbstractWidget w : mains) this.addRenderableWidget(w);
        FloatingMenu.set(this, panel, mains, sides);
    }
}
