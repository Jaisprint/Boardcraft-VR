package com.jay.cardboardvr;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Popup list of controller modes. Only Locked Crosshair works for now, the rest are dummies. */
public class VrControlModeScreen extends Screen {
    private final Screen parent;

    public VrControlModeScreen(Screen parent) {
        super(Component.literal("Controller Mode"));
        this.parent = parent;
    }

    private void pick(ControlMode m) {
        VrConfig.I.controlMode = m.ordinal();
        VrConfig.save();
        minecraft.setScreenAndShow(parent);
    }

    @Override
    protected void init() {
        int left = width / 2 - 155;
        ControlMode[] modes = ControlMode.values();
        int step = Math.max(20, Math.min(24, (height - 66) / modes.length));

        Button title = addRenderableWidget(Button.builder(
                Component.literal("Controller (now: " + ControlMode.selected().label + ")"), b -> {})
                .bounds(left, 6, 310, 20).build());
        title.active = false;

        ControlMode sel = ControlMode.selected();
        for (int i = 0; i < modes.length; i++) {
            final ControlMode m = modes[i];
            String text = (m == sel ? "> " : "") + m.label + (m.working ? "" : " (coming soon)");
            addRenderableWidget(Button.builder(Component.literal(text), b -> pick(m))
                    .bounds(left, 32 + i * step, 310, 20).build());
        }

        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose())
                .bounds(width / 2 - 50, height - 26, 100, 20).build());
    }

    @Override
    public void onClose() {
        minecraft.setScreenAndShow(parent);
    }
}
