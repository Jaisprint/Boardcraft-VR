package com.jay.cardboardvr;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.SpriteIconButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Floating 3D menus (title screen and pause menu while VR is on).
 *
 * - The menu buttons are real widgets (so touch / click still works) that are moved every frame: head turn
 *   gives parallax between layers, plus a slow bob.
 * - ScreenDrawMixin calls draw() at the end of Screen.extractRenderState. draw() paints 3D slabs over the
 *   vanilla buttons: shadow, thickness (its direction follows your head), a shaded face and the label.
 * - A round crosshair sits in the middle of the view. It is a solid dot; when it is over a button it smoothly
 *   opens into a hollow ring and the button lifts and lights up.
 * - On the title screen the panorama follows your head (PanoramaMixin).
 */
public class FloatingMenu {
    private static final class Item {
        final AbstractWidget w;
        final int bx, by;
        final float depth, phase;
        final boolean main;
        float hover;
        Item(AbstractWidget w, float depth, float phase, boolean main) {
            this.w = w;
            this.bx = w.getX();
            this.by = w.getY();
            this.depth = depth;
            this.phase = phase;
            this.main = main;
        }
    }

    static final float PX_PER_DEG = 1.0f;
    static final float MAX_PX = 24f;
    static final float DEPTH_SLAB = 0.7f, DEPTH_MAIN = 1.0f, DEPTH_SIDE = 1.4f;

    private static Screen screen;
    private static final List<Item> items = new ArrayList<>();
    private static float ox, oy, ringA;
    private static int slabX, slabY, slabW, slabH;
    private static boolean slabOn;
    private static long lastDrawNs;

    /** Last time the panorama hook ran with head tracking (shown in settings so a missing hook is visible). */
    public static volatile long panoHitMs = 0;
    private static volatile long panoFallbackMs = 0;
    public static volatile int drawHits = 0;
    private static int lastMains, lastSides;
    private static boolean logged;
    private static Object panoObj;
    private static Field spinF;

    // ---------- when is it on ----------

    /** Title screen needs VR mode ON (menus too). The pause menu is shown in VR for ON and World only. */
    public static boolean wantedFor(Screen s) {
        VrConfig c = VrConfig.I;
        if (!c.floatingMenus) return false;
        return s instanceof TitleScreen ? c.vrMode == 1 : c.vrMode != 0;
    }

    public static boolean wanted() {
        VrConfig c = VrConfig.I;
        return c.floatingMenus && c.vrMode == 1;
    }

    // ---------- attach ----------

    /** Called at the end of a screen's init (title screen, pause screen). */
    public static void attach(Screen s) {
        clear();
        if (!wantedFor(s)) return;
        if (s instanceof TitleScreen) logOnce();
        List<AbstractWidget> mains = new ArrayList<>(), sides = new ArrayList<>();
        for (var ch : s.children()) {
            if (ch instanceof AbstractWidget w) {
                // Buttons are Button.Plain (a subclass of Button), so use instanceof, never getClass() ==
                if (w instanceof SpriteIconButton) sides.add(w);                                            // icons
                else if (w instanceof Button && w.getHeight() == 20 && w.getWidth() >= 90) mains.add(w);    // text buttons
            }
        }
        screen = s;
        lastMains = mains.size();
        lastSides = sides.size();
        if (s instanceof TitleScreen) findPano(Minecraft.getInstance(), s);
        for (AbstractWidget w : mains) items.add(new Item(w, DEPTH_MAIN, 0f, true));
        for (AbstractWidget w : sides) items.add(new Item(w, DEPTH_SIDE, 1.7f, false));
        slabOn = !mains.isEmpty();
        if (slabOn) {
            int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
            for (AbstractWidget w : mains) {
                minX = Math.min(minX, w.getX());
                minY = Math.min(minY, w.getY());
                maxX = Math.max(maxX, w.getX() + w.getWidth());
                maxY = Math.max(maxY, w.getY() + w.getHeight());
            }
            int pad = 6;
            slabX = minX - pad;
            slabY = minY - pad;
            slabW = (maxX - minX) + pad * 2;
            slabH = (maxY - minY) + pad * 2;
        }
        ox = 0f;
        oy = 0f;
        ringA = 0f;
        lastDrawNs = 0;
    }

    public static void clear() {
        screen = null;
        items.clear();
        slabOn = false;
    }

    // ---------- per-frame movement ----------

    private static float wrap(float d) {
        while (d > 180f) d -= 360f;
        while (d < -180f) d += 360f;
        return d;
    }

    private static float clamp(float v) {
        return Math.max(-MAX_PX, Math.min(MAX_PX, v));
    }

    /** Render thread, start of every frame (or once per tick if the render hook is missing). */
    public static void frame(Minecraft mc) {
        if (screen == null) return;
        if (ScreenCompat.current(mc) != screen || !wantedFor(screen)) {
            for (Item it : items) it.w.setPosition(it.bx, it.by);   // put everything back where vanilla had it
            clear();
            return;
        }
        float tx = 0f, ty = 0f;
        GyroReceiver g = GyroReceiver.I;
        if (screen instanceof TitleScreen) {
            if (g.menuPoseActive()) {
                tx = clamp(-wrap(g.menuYaw()) * PX_PER_DEG);
                ty = clamp(-g.menuPitch() * PX_PER_DEG);
            }
        } else if (mc.player != null && g.isActive() && VrConfig.I.tracking) {
            // pause menu: head turn since the game was paused (the camera is frozen while the menu is open)
            tx = clamp(-wrap(g.yawDeg() - mc.player.getYRot()) * PX_PER_DEG);
            ty = clamp(-(g.pitchDeg() - mc.player.getXRot()) * PX_PER_DEG);
        }
        // Fallback if the CubeMap hook is not matching: turn the title panorama (yaw only) through its own spin value.
        if (spinF != null && panoObj != null && panoActive(mc) && System.currentTimeMillis() - panoHitMs > 1000) {
            try {
                float yaw = g.menuYaw();
                spinF.setFloat(panoObj, -(VrConfig.I.panoInvertYaw ? -yaw : yaw) * 10f);
                panoFallbackMs = System.currentTimeMillis();
            } catch (Throwable ignored) {
                spinF = null;
            }
        }
        ox += (tx - ox) * 0.25f;
        oy += (ty - oy) * 0.25f;
        double t = System.nanoTime() / 1.0e9;
        for (Item it : items) {
            float bobX = (float) Math.sin(t * 0.9 + it.phase) * 1.0f;
            float bobY = (float) Math.sin(t * 1.3 + it.phase) * 2.0f;
            int x = it.bx + Math.round((ox + bobX) * it.depth);
            int y = it.by + Math.round((oy + bobY) * it.depth);
            it.w.setPosition(x, y);
        }
    }

    // ---------- drawing (3D buttons + crosshair) ----------

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (a >>> 24) & 255, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return (Math.round(aa + (ba - aa) * t) << 24) | (Math.round(ar + (br - ar) * t) << 16)
                | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }

    private static void rect(GuiGraphicsExtractor g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + h, argb);
    }

    /** Called from ScreenDrawMixin at the end of Screen.extractRenderState. */
    public static void draw(Screen s, GuiGraphicsExtractor g) {
        if (s != screen || items.isEmpty()) return;
        drawHits++;
        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;

        long now = System.nanoTime();
        float dt = lastDrawNs == 0 ? 0.016f : Math.min(0.1f, (now - lastDrawNs) / 1.0e9f);
        lastDrawNs = now;
        float k = 1f - (float) Math.exp(-dt * 14.0);   // smooth, frame-rate independent easing
        double t = now / 1.0e9;

        // what is the crosshair (middle of the view) pointing at?
        int cx = s.width / 2, cy = s.height / 2;
        Item hov = null;
        for (Item it : items) {
            AbstractWidget w = it.w;
            if (!w.visible || !w.active) continue;
            if (cx >= w.getX() && cx < w.getX() + w.getWidth() && cy >= w.getY() && cy < w.getY() + w.getHeight()) {
                hov = it;
                break;
            }
        }
        for (Item it : items) it.hover += ((it == hov ? 1f : 0f) - it.hover) * k;
        ringA += ((hov != null ? 1f : 0f) - ringA) * k;

        // slab behind the buttons
        if (slabOn) {
            float bobX = (float) Math.sin(t * 0.9) * 1.0f, bobY = (float) Math.sin(t * 1.3) * 2.0f;
            int sx = slabX + Math.round((ox + bobX) * DEPTH_SLAB);
            int sy = slabY + Math.round((oy + bobY) * DEPTH_SLAB);
            int tx = Math.round(2f + ox * 0.08f), ty = Math.round(3f + oy * 0.08f);
            rect(g, sx + tx * 3 + 3, sy + ty * 3 + 4, slabW, slabH, 0x38000000);
            for (int i = 3; i >= 1; i--) rect(g, sx + tx * i, sy + ty * i, slabW, slabH, lerp(0xFF0e0f16, 0xFF1c1e2a, (3 - i) / 2f));
            rect(g, sx, sy, slabW, slabH, 0xB0222532);
            rect(g, sx, sy, slabW, 1, 0x55FFFFFF);
            rect(g, sx, sy, 1, slabH, 0x40FFFFFF);
            rect(g, sx, sy + slabH - 1, slabW, 1, 0x50000000);
            rect(g, sx + slabW - 1, sy, 1, slabH, 0x40000000);
        }

        // 3D buttons
        for (Item it : items) {
            if (!it.main || !it.w.visible) continue;
            AbstractWidget w = it.w;
            float a = it.hover;
            int lift = Math.round(a * 2f);
            int fx = w.getX() - lift, fy = w.getY() - lift, fw = w.getWidth(), fh = w.getHeight();
            float par = 1f + a;
            int tx = Math.max(-6, Math.min(6, Math.round((2f + ox * 0.12f) * par)));
            int ty = Math.max(0, Math.min(8, Math.round((3f + oy * 0.12f) * par)));
            int n = Math.max(1, Math.max(Math.abs(tx), ty));

            rect(g, fx + tx * 2 + 2, fy + ty * 2 + 3, fw, fh, 0x44000000);                       // shadow
            for (int i = n; i >= 1; i--) {                                                       // thickness
                rect(g, fx + Math.round(tx * i / (float) n), fy + Math.round(ty * i / (float) n), fw, fh,
                        lerp(0xFF12131b, lerp(0xFF2c2f3f, 0xFF2f5f8a, a), (n - i) / (float) Math.max(1, n - 1)));
            }
            int top = lerp(w.active ? 0xFF6d7184 : 0xFF50525c, 0xFF8fd8ff, a);                   // face, vertical gradient
            int bot = lerp(w.active ? 0xFF3e4256 : 0xFF2f313a, 0xFF3f82bd, a);
            for (int r = 0; r < fh; r++) rect(g, fx, fy + r, fw, 1, lerp(top, bot, r / (float) Math.max(1, fh - 1)));
            rect(g, fx, fy, fw, 1, 0x80FFFFFF);                                                  // bevel
            rect(g, fx, fy, 1, fh, 0x55FFFFFF);
            rect(g, fx, fy + fh - 1, fw, 1, 0x70000000);
            rect(g, fx + fw - 1, fy, 1, fh, 0x55000000);

            Component msg = w.getMessage();
            int tw = font.width(msg);
            int col = w.active ? lerp(0xFFFFFFFF, 0xFFFFFFB0, a) : 0xFFA0A0A0;
            g.text(font, msg, fx + (fw - tw) / 2, fy + (fh - 8) / 2, col, true);
        }

        // round crosshair: solid dot -> hollow ring while pointing at a button
        float a = ringA;
        float ro = 2.5f + a * 5.5f + (float) Math.sin(t * 6.0) * 0.4f * a;
        float ri = a * (ro - 2.0f);
        disc(g, cx, cy, ro + 1f, ri > 0.2f ? ri - 1f : 0f, 0x99000000);
        disc(g, cx, cy, ro, ri, lerp(0xF0FFFFFF, 0xF08affc0, a));
    }

    /** Filled disc (inner radius 0) or ring, drawn as horizontal spans. */
    private static void disc(GuiGraphicsExtractor g, int cx, int cy, float ro, float ri, int argb) {
        int r = (int) Math.ceil(ro);
        for (int dy = -r; dy <= r; dy++) {
            float o2 = ro * ro - dy * dy;
            if (o2 < 0f) continue;
            int xo = (int) Math.floor(Math.sqrt(o2));
            if (ri > 0f && Math.abs(dy) < ri) {
                int xi = (int) Math.ceil(Math.sqrt(ri * ri - dy * dy));
                if (xi > xo) continue;
                g.fill(cx - xo, cy + dy, cx - xi + 1, cy + dy + 1, argb);
                g.fill(cx + xi, cy + dy, cx + xo + 1, cy + dy + 1, argb);
            } else {
                g.fill(cx - xo, cy + dy, cx + xo + 1, cy + dy + 1, argb);
            }
        }
    }

    // ---------- panorama (3D background) ----------

    public static boolean panoActive(Minecraft mc) {
        return wanted() && mc.player == null && GyroReceiver.I.menuPoseActive();
    }

    public static float panoYaw(float vanilla) {
        Minecraft mc = Minecraft.getInstance();
        if (!panoActive(mc)) return vanilla;
        panoHitMs = System.currentTimeMillis();
        float y = GyroReceiver.I.menuYaw();
        return VrConfig.I.panoInvertYaw ? -y : y;
    }

    public static float panoPitch(float vanilla) {
        Minecraft mc = Minecraft.getInstance();
        if (!panoActive(mc)) return vanilla;
        float p = GyroReceiver.I.menuPitch();
        return VrConfig.I.panoInvertPitch ? -p : p;
    }

    public static String panoStatus() {
        if (!wanted()) return "Needs VR mode ON";
        if (!GyroReceiver.I.isActive()) return "Panorama: no gyro";
        long now = System.currentTimeMillis();
        if (now - panoHitMs < 1500) return "Panorama: tracked";
        if (now - panoFallbackMs < 1500) return "Panorama: yaw only";
        return "Panorama: waiting";
    }

    public static String attachStatus() {
        if (lastMains + lastSides == 0) return "Floating: nothing attached yet";
        return "Floating: " + lastMains + " buttons, " + lastSides + " icons, drawn: " + (drawHits > 0 ? "YES" : "NO");
    }

    private static void findPano(Minecraft mc, Screen s) {
        panoObj = null;
        spinF = null;
        try {
            Object[] holders = {s, mc.gameRenderer, mc};
            for (Object h : holders) {
                if (h == null || panoObj != null) continue;
                for (Class<?> k = h.getClass(); k != null && k != Object.class && panoObj == null; k = k.getSuperclass()) {
                    for (Field f : k.getDeclaredFields()) {
                        if (f.getType().getSimpleName().equals("PanoramaRenderer")) {
                            f.setAccessible(true);
                            panoObj = f.get(h);
                            break;
                        }
                    }
                }
            }
            if (panoObj != null) {
                for (Class<?> k = panoObj.getClass(); k != null && k != Object.class && spinF == null; k = k.getSuperclass()) {
                    for (Field f : k.getDeclaredFields()) {
                        if (f.getName().equals("spin") && f.getType() == float.class) {
                            f.setAccessible(true);
                            spinF = f;
                            break;
                        }
                    }
                }
            }
        } catch (Throwable t) {
            panoObj = null;
            spinF = null;
        }
    }

    /** Writes the real panorama class signatures to the log once, so a missed hook can be fixed from latest.log. */
    private static void logOnce() {
        if (logged) return;
        logged = true;
        String[] names = {"net.minecraft.client.renderer.CubeMap",
                "net.minecraft.client.gui.components.PanoramaRenderer",
                "net.minecraft.client.renderer.PanoramaRenderer"};
        for (String n : names) {
            try {
                Class<?> k = Class.forName(n, false, FloatingMenu.class.getClassLoader());
                for (Method m : k.getDeclaredMethods()) CardboardVrClient.LOG.info("[pano] {}", m.toGenericString());
                for (Field f : k.getDeclaredFields()) CardboardVrClient.LOG.info("[pano] field {} {}", f.getType().getSimpleName(), f.getName());
            } catch (Throwable t) {
                CardboardVrClient.LOG.info("[pano] {} not found", n);
            }
        }
    }
}
