package com.jay.cardboardvr.mixin;

import com.jay.cardboardvr.FloatingMenu;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Draws the 3D floating buttons and the round crosshair on top of the vanilla widgets (26.x: Screen.render is now
 * extractRenderState). Does nothing unless FloatingMenu attached this exact screen. require = 0: if the method
 * ever changes, the vanilla menu is simply left as it is.
 */
@Mixin(Screen.class)
public abstract class ScreenDrawMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"), require = 0)
    private void cardboardvr$floatDraw(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partial, CallbackInfo ci) {
        FloatingMenu.draw((Screen) (Object) this, graphics);
    }
}
