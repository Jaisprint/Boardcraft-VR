package com.jay.cardboardvr;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class VrConfig {
    // input slots: 0 TAP, 1 BACK, 2 VOL_UP, 3 VOL_DOWN
    // actions: 0 none, 1 attack, 2 use/place, 3 jump, 4 inventory, 5 pause menu
    public boolean vrEnabled = false;
    public boolean tracking = true;
    public int port = 9876;
    public float lookSens = 1.0f;
    public float smoothing = 0.3f;
    public float mouseSens = 1.0f;
    public float deadZone = 2.0f;
    public boolean invertX = false;
    public boolean invertY = false;
    public int[] codes = {0, 0, 0, 0};
    public int[] actions = {1, 2, 4, 3};

    public static VrConfig I = new VrConfig();

    static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("cardboardvr.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                VrConfig c = new Gson().fromJson(Files.readString(p), VrConfig.class);
                if (c != null) I = c;
            }
        } catch (Exception e) {
            CardboardVrClient.LOG.warn("Could not read config, using defaults", e);
        }
        I.fix();
    }

    public static void save() {
        try {
            Files.writeString(path(), new GsonBuilder().setPrettyPrinting().create().toJson(I));
        } catch (Exception e) {
            CardboardVrClient.LOG.warn("Could not save config", e);
        }
    }

    public void resetBindings() {
        codes = new int[]{0, 0, 0, 0};
        actions = new int[]{1, 2, 4, 3};
    }

    void fix() {
        if (codes == null || codes.length != 4) codes = new int[]{0, 0, 0, 0};
        if (actions == null || actions.length != 4) actions = new int[]{1, 2, 4, 3};
        for (int i = 0; i < 4; i++) if (actions[i] < 0 || actions[i] > 5) actions[i] = 0;
        if (port < 1024 || port > 65535) port = 9876;
        if (lookSens <= 0) lookSens = 1f;
        if (smoothing < 0 || smoothing > 0.9f) smoothing = 0.3f;
        if (mouseSens <= 0) mouseSens = 1f;
        if (deadZone < 0) deadZone = 2f;
    }
}
