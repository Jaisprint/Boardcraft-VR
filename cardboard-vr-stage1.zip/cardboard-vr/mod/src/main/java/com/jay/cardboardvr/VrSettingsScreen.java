package com.jay.cardboardvr;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.Supplier;

public class VrSettingsScreen extends Screen {
    private final Screen parent;
    private EditBox portBox;
    private Button status;

    static final float[] LOOK = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};
    static final float[] SMOOTH = {0f, 0.2f, 0.4f, 0.6f, 0.8f};
    static final float[] MSENS = {0.5f, 1f, 1.5f, 2f, 3f};
    static final float[] DEAD = {0.5f, 1f, 2f, 3f, 5f};

    public VrSettingsScreen(Screen parent) {
        super(Component.literal("Cardboard VR Settings"));
        this.parent = parent;
    }

    static float next(float[] a, float v) {
        int best = 0;
        float bd = 1e9f;
        for (int i = 0; i < a.length; i++) {
            float d = Math.abs(a[i] - v);
            if (d < bd) { bd = d; best = i; }
        }
        return a[(best + 1) % a.length];
    }

    static String onOff(boolean b) { return b ? "ON" : "OFF"; }

    private Button btn(int x, int y, int w, Supplier<String> label, Runnable action) {
        Button b = Button.builder(Component.literal(label.get()), bb -> {
            action.run();
            VrConfig.save();
            bb.setMessage(Component.literal(label.get()));
        }).bounds(x, y, w, 20).build();
        return addRenderableWidget(b);
    }

    @Override
    protected void init() {
        VrConfig c = VrConfig.I;
        int lx = width / 2 - 155, rx = width / 2 + 5, y = 36, s = 24;

        addRenderableWidget(Button.builder(Component.literal("Cardboard VR Settings"), b -> {})
                .bounds(lx, 8, 310, 20).build()).active = false;

        btn(lx, y, 150, () -> "VR: " + onOff(c.vrEnabled), () -> c.vrEnabled = !c.vrEnabled);
        btn(lx, y + s, 150, () -> "Head tracking: " + onOff(c.tracking), () -> c.tracking = !c.tracking);
        btn(lx, y + s * 2, 150, () -> "Recenter view", () -> GyroReceiver.I.recenter = true);

        portBox = new EditBox(font, lx, y + s * 3, 100, 20, Component.literal("Gyro port"));
        portBox.setValue(String.valueOf(c.port));
        portBox.setHint(Component.literal("Gyro port"));
        addRenderableWidget(portBox);
        addRenderableWidget(Button.builder(Component.literal("Apply"), b -> applyPort())
                .bounds(lx + 104, y + s * 3, 46, 20).build());

        btn(lx, y + s * 4, 150, () -> String.format("Look sens: x%.2f", c.lookSens), () -> c.lookSens = next(LOOK, c.lookSens));
        btn(lx, y + s * 5, 150, () -> String.format("Smoothing: %.1f", c.smoothing), () -> c.smoothing = next(SMOOTH, c.smoothing));

        btn(rx, y, 150, () -> String.format("Walk sens: x%.1f", c.mouseSens), () -> c.mouseSens = next(MSENS, c.mouseSens));
        btn(rx, y + s, 150, () -> "Invert left/right: " + onOff(c.invertX), () -> c.invertX = !c.invertX);
        btn(rx, y + s * 2, 150, () -> "Invert fwd/back: " + onOff(c.invertY), () -> c.invertY = !c.invertY);
        btn(rx, y + s * 3, 150, () -> String.format("Dead zone: %.1f", c.deadZone), () -> c.deadZone = next(DEAD, c.deadZone));
        addRenderableWidget(Button.builder(Component.literal("Controls..."),
                b -> minecraft.setScreen(new VrControlsScreen(this))).bounds(rx, y + s * 4, 150, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(rx, y + s * 5, 150, 20).build());

        status = addRenderableWidget(Button.builder(Component.literal("..."), b -> {})
                .bounds(lx, y + s * 6 + 4, 310, 20).build());
        status.active = false;
    }

    private void applyPort() {
        try {
            int p = Integer.parseInt(portBox.getValue().trim());
            if (p >= 1024 && p <= 65535) {
                VrConfig.I.port = p;
                VrConfig.save();
                GyroReceiver.I.start(p);
            }
        } catch (NumberFormatException ignored) {
        }
    }

    @Override
    public void tick() {
        super.tick();
        GyroReceiver g = GyroReceiver.I;
        String t;
        if (!g.bound) t = "Can't open port " + VrConfig.I.port + " (already in use?)";
        else if (g.isActive()) t = String.format("Gyro OK %d/s  yaw %.0f  pitch %.0f", g.pps, g.yawDeg(), g.pitchDeg());
        else t = "No gyro data - start the sender app (port " + VrConfig.I.port + ")";
        status.setMessage(Component.literal(t));
    }

    @Override
    public void onClose() {
        VrConfig.save();
        minecraft.setScreen(parent);
    }
}
