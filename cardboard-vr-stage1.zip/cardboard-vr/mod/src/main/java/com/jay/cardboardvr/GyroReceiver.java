package com.jay.cardboardvr;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;

/**
 * Listens on 127.0.0.1:port for "fx,fy,fz" (look direction in East/North/Up) from the gyro app,
 * turns it into yaw/pitch and writes it to the player's rotation. Head only ever rotates the view;
 * it never touches movement.
 */
public class GyroReceiver implements TrackingProvider {
    public static final GyroReceiver I = new GyroReceiver();

    public volatile boolean bound = false;
    public volatile long lastPacketMs = 0;
    public volatile int pps = 0;
    public volatile boolean recenter = true;
    private volatile float outYaw, outPitch;

    private DatagramSocket socket;
    private int count;
    private long ppsT;
    private float lastH, baseYaw, yawAccum, sYaw, sPitch;
    private boolean haveLast;

    public synchronized void start(int port) {
        stop();
        try {
            socket = new DatagramSocket(new InetSocketAddress(InetAddress.getLoopbackAddress(), port));
            socket.setSoTimeout(500);
            bound = true;
        } catch (Exception e) {
            CardboardVrClient.LOG.warn("Could not open UDP port {}", port, e);
            socket = null;
            bound = false;
            return;
        }
        final DatagramSocket s = socket;
        Thread t = new Thread(() -> loop(s), "cardboardvr-udp");
        t.setDaemon(true);
        t.start();
    }

    public synchronized void stop() {
        if (socket != null) socket.close();
        socket = null;
        bound = false;
    }

    private void loop(DatagramSocket s) {
        byte[] buf = new byte[128];
        while (!s.isClosed()) {
            try {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                s.receive(p);
                handle(new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8));
            } catch (SocketTimeoutException ignored) {
            } catch (Exception e) {
                if (s.isClosed()) break;
            }
        }
    }

    private void handle(String msg) {
        long now = System.currentTimeMillis();
        lastPacketMs = now;
        count++;
        if (now - ppsT >= 1000) { pps = count; count = 0; ppsT = now; }

        VrConfig c = VrConfig.I;
        if (!c.vrEnabled || !c.tracking) { haveLast = false; return; }

        String[] p = msg.trim().split(",");
        if (p.length < 3) return;
        float fx, fy, fz;
        try {
            fx = Float.parseFloat(p[0]);
            fy = Float.parseFloat(p[1]);
            fz = Float.parseFloat(p[2]);
        } catch (NumberFormatException e) {
            return;
        }

        float h = (float) Math.toDegrees(Math.atan2(fx, fy));
        float pitch = (float) Math.toDegrees(Math.asin(Math.max(-1f, Math.min(1f, fz))));
        if (!haveLast) { lastH = h; haveLast = true; }
        float d = h - lastH;
        while (d > 180) d -= 360;
        while (d < -180) d += 360;
        lastH = h;
        yawAccum += d;

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer pl = mc.player;
        if (pl == null) return;

        if (recenter) {
            recenter = false;
            baseYaw = pl.getYRot();
            yawAccum = 0;
            sYaw = 0;
            sPitch = pitch;
        }

        float a = 1f - c.smoothing;
        sYaw += a * (yawAccum - sYaw);
        sPitch += a * (pitch - sPitch);

        float ty = baseYaw + sYaw * c.lookSens;
        float tp = Math.max(-90f, Math.min(90f, -sPitch * c.lookSens));
        outYaw = ty;
        outPitch = tp;

        if (mc.screen == null) {
            pl.setYRot(ty);
            pl.setXRot(tp);
        }
    }

    @Override public boolean isActive() { return System.currentTimeMillis() - lastPacketMs < 500; }
    @Override public float yawDeg() { return outYaw; }
    @Override public float pitchDeg() { return outPitch; }
}
