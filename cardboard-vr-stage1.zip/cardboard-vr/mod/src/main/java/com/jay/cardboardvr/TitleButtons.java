package com.jay.cardboardvr;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;

/**
 * Adds "VR: ON/OFF" and "VR Settings" next to the main-menu buttons.
 * If this file fails to compile on your Fabric API version, delete it and remove the
 * TitleButtons.register() line in CardboardVrClient. F9 still opens the settings.
 */
public class TitleButtons {
    static String label() { return "VR: " + (VrConfig.I.vrEnabled ? "ON" : "OFF"); }

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen) {
                int x = w / 2 + 104, y = h / 4 + 48;
                Button toggle = Button.builder(Component.literal(label()), b -> {
                    VrConfig.I.vrEnabled = !VrConfig.I.vrEnabled;
                    VrConfig.save();
                    b.setMessage(Component.literal(label()));
                }).bounds(x, y, 80, 20).build();
                Button settings = Button.builder(Component.literal("VR Settings"),
                        b -> client.setScreen(new VrSettingsScreen(screen))).bounds(x, y + 24, 80, 20).build();
                Screens.getButtons(screen).add(toggle);
                Screens.getButtons(screen).add(settings);
            }
        });
    }
}
