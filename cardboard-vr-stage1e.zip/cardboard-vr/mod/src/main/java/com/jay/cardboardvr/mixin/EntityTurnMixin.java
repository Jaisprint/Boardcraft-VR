package com.jay.cardboardvr.mixin;

import com.jay.cardboardvr.VrConfig;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Blocks Minecraft's own mouse/controller camera turning for the local player while VR is ON,
 * so only head tracking rotates the view (the mouse is walk-only).
 * require = 0: if this method isn't found in a future version the mod still loads.
 */
@Mixin(Entity.class)
public abstract class EntityTurnMixin {
    @Inject(method = "turn(DD)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void cardboardvr$noMouseLook(double yRot, double xRot, CallbackInfo ci) {
        if (VrConfig.I.vrEnabled && (Object) this instanceof LocalPlayer) {
            ci.cancel();
        }
    }
}
