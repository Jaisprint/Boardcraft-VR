package com.crl.minecraft.cardboard.vr;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private EditText portE;
    private Button btn;
    private TextView status, viewerStatus;
    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("gyro", MODE_PRIVATE);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(48, 96, 48, 48);

        TextView title = new TextView(this);
        title.setText("Cardboard Gyro Sender");
        title.setTextSize(24);
        l.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Port must match the port in the Minecraft mod's VR Settings (default 9876).");
        l.addView(hint);

        portE = new EditText(this);
        portE.setInputType(InputType.TYPE_CLASS_NUMBER);
        portE.setText(String.valueOf(sp.getInt("port", 9876)));
        l.addView(portE);

        btn = new Button(this);
        l.addView(btn);

        status = new TextView(this);
        status.setTextSize(18);
        l.addView(status);

        TextView vt = new TextView(this);
        vt.setText("\nViewer (lens) settings");
        vt.setTextSize(20);
        l.addView(vt);

        Button scan = new Button(this);
        scan.setText("Scan viewer QR");
        l.addView(scan);

        Button clear = new Button(this);
        clear.setText("Clear viewer");
        l.addView(clear);

        viewerStatus = new TextView(this);
        l.addView(viewerStatus);

        setContentView(l);

        btn.setOnClickListener(v -> {
            if (GyroService.running) {
                stopService(new Intent(this, GyroService.class));
            } else {
                int port = readPort();
                sp.edit().putInt("port", port).apply();
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                }
                Intent i = new Intent(this, GyroService.class).putExtra("port", port);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            }
            btn.postDelayed(this::refresh, 400);
        });

        scan.setOnClickListener(v -> {
            IntentIntegrator ii = new IntentIntegrator(this);
            ii.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
            ii.setPrompt("Scan the QR code on your Cardboard viewer");
            ii.setBeepEnabled(false);
            ii.setOrientationLocked(false);
            ii.initiateScan();
        });

        clear.setOnClickListener(v -> {
            sp.edit().remove("vp").remove("vsum").apply();
            // tell the mod right away too (empty viewer)
            sendNow("VP0\n");
            refresh();
        });

        refresh();
    }

    private int readPort() {
        int port = 9876;
        try { port = Integer.parseInt(portE.getText().toString().trim()); } catch (Exception ignored) {}
        if (port < 1024 || port > 65535) port = 9876;
        return port;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        IntentResult r = IntentIntegrator.parseActivityResult(req, res, data);
        if (r != null) {
            String text = r.getContents();
            if (text == null) {
                viewerStatus.setText("Scan cancelled.");
            } else {
                viewerStatus.setText("Reading viewer data...");
                new Thread(() -> {
                    String msg;
                    try {
                        ViewerParams vp = ViewerParams.parse(ViewerParams.fromScan(text));
                        sp.edit().putString("vp", vp.toWire()).putString("vsum", vp.summary()).apply();
                        sendNow(vp.toWire());
                        msg = null;
                    } catch (Exception e) {
                        msg = "Could not read that QR: " + e.getMessage();
                    }
                    final String m = msg;
                    runOnUiThread(() -> {
                        refresh();
                        if (m != null) viewerStatus.setText(m);
                    });
                }).start();
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    /** One-off send to the mod (the service re-sends it every ~2 s while running). */
    private void sendNow(String msg) {
        final int port = readPort();
        new Thread(() -> {
            try (DatagramSocket s = new DatagramSocket()) {
                byte[] d = msg.getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(d, d.length, InetAddress.getByName("127.0.0.1"), port));
            } catch (Exception ignored) {
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        boolean r = GyroService.running;
        btn.setText(r ? "Stop" : "Start");
        status.setText(r ? "Running. Now open Minecraft." : "Stopped.");
        String vs = sp.getString("vsum", null);
        viewerStatus.setText(vs != null ? "Saved viewer:\n" + vs + "\n(sent to the mod automatically while Running)"
                : "No viewer scanned yet. Scan the QR on your Cardboard.");
    }
}
