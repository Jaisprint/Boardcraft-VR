package com.crl.gyroscope.sender;
public class ParserSmokeTest {
 public static void main(String[] a) {
  CardboardViewerParams p = CardboardViewerParams.fromQr(a[0]);
  System.out.println(p.vendor + " / " + p.model);
  System.out.println(p.screenToLensMeters + " " + p.interLensMeters + " " + p.trayToLensMeters);
  System.out.println(p.fovSummary());
  System.out.println(p.distortionSummary());
 }
}
