package android.net;
public class Uri {
  private final String value;
  private Uri(String value){this.value=value;}
  public static Uri parse(String value){return new Uri(value);}
  public String getQueryParameter(String key){
    int q=value.indexOf('?'); if(q<0)return null;
    String[] parts=value.substring(q+1).split("&");
    for(String part:parts){int e=part.indexOf('='); if(e>=0 && part.substring(0,e).equals(key)) return part.substring(e+1).replace("%3D","=").replace("%2B","+");}
    return null;
  }
}
