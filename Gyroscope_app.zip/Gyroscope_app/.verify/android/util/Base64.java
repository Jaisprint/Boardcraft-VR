package android.util;
public class Base64 {
  public static final int URL_SAFE=8, NO_WRAP=2, NO_PADDING=1, DEFAULT=0;
  public static byte[] decode(String s,int flags){
    String v=s.replaceAll("\\s", "");
    int m=v.length()%4; if(m!=0)v += "=".repeat(4-m);
    return (flags & URL_SAFE)!=0 ? java.util.Base64.getUrlDecoder().decode(v) : java.util.Base64.getDecoder().decode(v);
  }
  public static String encodeToString(byte[] b,int flags){
    return (flags & URL_SAFE)!=0 ? java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(b) : java.util.Base64.getEncoder().encodeToString(b);
  }
}
