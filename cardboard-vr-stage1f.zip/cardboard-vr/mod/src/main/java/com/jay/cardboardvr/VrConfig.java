package com.jay.cardboardvr;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class VrConfig {
    // input slots: 0 Tap, 1 Back, 2 Vol Up, 3 Vol Down
    public boolean vrEnabled = false;
    public boolean tracking = true;
    public int port = 9876;
    public float lookSens = 1.0f;
    public float smoothing = 0.3f;
    public int moveMode = 0;          // 0 = mouse deltas -> walking, 1 = gamepad (launcher maps stick to WASD)
    public float mouseSens = 1.5f;
    public float deadZone = 1.0f;
    public boolean invertX = false;
    public boolean invertY = false;
    public int[] codes = {0, 0, 0, 0};
    public String[] acts = defaultActs();
    public double savedSens = -1;     // the player's real mouse sensitivity while VR forces it to 0

    public static VrConfig I = new VrConfig();

    public static String[] defaultActs() {
        return new String[]{"key.attack", "key.use", "key.inventory", "key.jump"};
    }

    static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("cardboardvr.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                VrConfig c = new Gson().fromJson(Files.readString(p), VrConfig.class);
                if (c != null) I = c;
            }
        } catch (Exception e) {
            CardboardVrClient.LOG.warn("Could not read config, using defaults", e);
        }
        I.fix();
    }

    public static void save() {
        try {
            Files.writeString(path(), new GsonBuilder().setPrettyPrinting().create().toJson(I));
        } catch (Exception e) {
            CardboardVrClient.LOG.warn("Could not save config", e);
        }
    }

    public void resetBindings() {
        codes = new int[]{0, 0, 0, 0};
        acts = defaultActs();
    }

    void fix() {
        if (codes == null || codes.length != 4) codes = new int[]{0, 0, 0, 0};
        if (acts == null || acts.length != 4) acts = defaultActs();
        for (int i = 0; i < 4; i++) if (acts[i] == null) acts[i] = "";
        if (port < 1024 || port > 65535) port = 9876;
        if (lookSens <= 0) lookSens = 1f;
        if (smoothing < 0 || smoothing > 0.9f) smoothing = 0.3f;
        if (mouseSens <= 0) mouseSens = 1.5f;
        if (deadZone < 0) deadZone = 1f;
        if (moveMode < 0 || moveMode > 1) moveMode = 0;
    }
}
