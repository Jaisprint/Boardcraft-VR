package com.jay.cardboardvr;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Page-by-page list of every Minecraft key binding (plus two VR actions) to pick an action from. */
public class VrActionPickerScreen extends Screen {
    private final Screen parent;
    private final int slot;
    private int page = 0;
    private final List<String> names = new ArrayList<>();
    static final int PER = 5;

    public VrActionPickerScreen(Screen parent, int slot) {
        super(Component.literal("Choose action"));
        this.parent = parent;
        this.slot = slot;
    }

    @Override
    protected void init() {
        names.clear();
        names.add("");
        names.add(VrActions.PAUSE);
        names.add(VrActions.RECENTER);
        for (KeyMapping m : minecraft.options.keyMappings) names.add(m.getName());

        int lx = width / 2 - 155, y = 36, s = 24;
        int pages = (names.size() + PER - 1) / PER;
        if (page >= pages) page = pages - 1;
        if (page < 0) page = 0;

        Button title = addRenderableWidget(Button.builder(
                Component.literal("Action for " + VrControlsScreen.NAMES[slot]), b -> {})
                .bounds(lx, 8, 310, 20).build());
        title.active = false;

        for (int k = 0; k < PER; k++) {
            int idx = page * PER + k;
            if (idx >= names.size()) break;
            final String n = names.get(idx);
            addRenderableWidget(Button.builder(Component.literal(VrActions.label(n)), b -> {
                VrConfig.I.acts[slot] = n;
                VrConfig.save();
                minecraft.setScreenAndShow(parent);
            }).bounds(lx, y + s * k, 310, 20).build());
        }

        int py = y + s * PER + 4;
        Button prev = addRenderableWidget(Button.builder(Component.literal("< Prev"), b -> {
            page--;
            rebuildWidgets();
        }).bounds(lx, py, 100, 20).build());
        prev.active = page > 0;
        Button pg = addRenderableWidget(Button.builder(
                Component.literal("Page " + (page + 1) + "/" + pages), b -> {})
                .bounds(lx + 105, py, 100, 20).build());
        pg.active = false;
        Button nxt = addRenderableWidget(Button.builder(Component.literal("Next >"), b -> {
            page++;
            rebuildWidgets();
        }).bounds(lx + 210, py, 100, 20).build());
        nxt.active = page < pages - 1;

        addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose())
                .bounds(width / 2 - 100, height - 26, 200, 20).build());
    }

    @Override
    public void onClose() {
        minecraft.setScreenAndShow(parent);
    }
}
