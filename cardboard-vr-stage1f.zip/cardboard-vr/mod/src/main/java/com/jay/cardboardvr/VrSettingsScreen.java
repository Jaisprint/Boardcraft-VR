package com.jay.cardboardvr;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Tab 1: tracking. */
public class VrSettingsScreen extends VrBaseScreen {
    private EditBox portBox;

    static final float[] LOOK = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};
    static final float[] SMOOTH = {0f, 0.2f, 0.4f, 0.6f, 0.8f};

    public VrSettingsScreen(Screen parent) {
        super(parent, 0, "Boardcraft VR - Tracking");
    }

    @Override
    protected void init() {
        chrome();
        VrConfig c = VrConfig.I;
        int lx = width / 2 - 155, rx = width / 2 + 5, y = 36, s = 24;

        btn(lx, y, 150, () -> "VR: " + onOff(c.vrEnabled), () -> c.vrEnabled = !c.vrEnabled);
        btn(lx, y + s, 150, () -> "Head tracking: " + onOff(c.tracking), () -> c.tracking = !c.tracking);
        btn(lx, y + s * 2, 150, () -> "Recenter view", () -> GyroReceiver.I.recenter = true);

        portBox = new EditBox(font, lx, y + s * 3, 100, 20, Component.literal("Gyro port"));
        portBox.setValue(String.valueOf(c.port));
        portBox.setHint(Component.literal("Gyro port"));
        addRenderableWidget(portBox);
        addRenderableWidget(Button.builder(Component.literal("Apply"), b -> applyPort())
                .bounds(lx + 104, y + s * 3, 46, 20).build());

        btn(rx, y, 150, () -> String.format("Look sens: x%.2f", c.lookSens), () -> c.lookSens = next(LOOK, c.lookSens));
        btn(rx, y + s, 150, () -> String.format("Smoothing: %.1f", c.smoothing), () -> c.smoothing = next(SMOOTH, c.smoothing));
        note(rx, y + s * 2, 150, "Phone gyro app = head");
        note(rx, y + s * 3, 150, "Port must match app");
    }

    private void applyPort() {
        try {
            int p = Integer.parseInt(portBox.getValue().trim());
            if (p >= 1024 && p <= 65535) {
                VrConfig.I.port = p;
                VrConfig.save();
                GyroReceiver.I.start(p);
            }
        } catch (NumberFormatException ignored) {
        }
    }
}
