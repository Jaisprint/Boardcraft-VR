package com.jay.cardboardvr;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.Supplier;

/** Shared layout for the VR settings: tab bar on top, status line and Done at the bottom. */
public abstract class VrBaseScreen extends Screen {
    protected final Screen parent;
    private final int tab;
    protected Button status;

    static final String[] TABS = {"Tracking", "Movement", "Controls"};

    protected VrBaseScreen(Screen parent, int tab, String title) {
        super(Component.literal(title));
        this.parent = parent;
        this.tab = tab;
    }

    static Screen forTab(int t, Screen parent) {
        return t == 0 ? new VrSettingsScreen(parent) : t == 1 ? new VrMovementScreen(parent) : new VrControlsScreen(parent);
    }

    static float next(float[] a, float v) {
        int best = 0;
        float bd = 1e9f;
        for (int i = 0; i < a.length; i++) {
            float d = Math.abs(a[i] - v);
            if (d < bd) { bd = d; best = i; }
        }
        return a[(best + 1) % a.length];
    }

    static String onOff(boolean b) { return b ? "ON" : "OFF"; }

    protected void chrome() {
        int lx = width / 2 - 155;
        for (int i = 0; i < 3; i++) {
            final int k = i;
            Button b = Button.builder(Component.literal(TABS[i]), x -> {
                VrConfig.save();
                minecraft.setScreenAndShow(forTab(k, parent));
            }).bounds(lx + i * 105, 8, 100, 20).build();
            b.active = (i != tab);
            addRenderableWidget(b);
        }
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(width / 2 - 100, height - 26, 200, 20).build());
        status = addRenderableWidget(Button.builder(Component.literal("..."), b -> {})
                .bounds(lx, height - 50, 310, 20).build());
        status.active = false;
    }

    protected Button btn(int x, int y, int w, Supplier<String> label, Runnable action) {
        Button b = Button.builder(Component.literal(label.get()), bb -> {
            action.run();
            VrConfig.save();
            bb.setMessage(Component.literal(label.get()));
        }).bounds(x, y, w, 20).build();
        return addRenderableWidget(b);
    }

    protected Button note(int x, int y, int w, String text) {
        Button b = Button.builder(Component.literal(text), bb -> {}).bounds(x, y, w, 20).build();
        b.active = false;
        return addRenderableWidget(b);
    }

    protected String statusText() {
        GyroReceiver g = GyroReceiver.I;
        String t;
        if (!g.bound) t = "Port " + VrConfig.I.port + " in use";
        else if (g.isActive()) t = String.format("Gyro OK %d/s", g.pps);
        else t = "No gyro (port " + VrConfig.I.port + ")";
        return t + " | look-block " + Diag.lookBlocked.get();
    }

    @Override
    public void tick() {
        super.tick();
        if (status != null) status.setMessage(Component.literal(statusText()));
    }

    @Override
    public void onClose() {
        VrConfig.save();
        minecraft.setScreenAndShow(parent);
    }
}
