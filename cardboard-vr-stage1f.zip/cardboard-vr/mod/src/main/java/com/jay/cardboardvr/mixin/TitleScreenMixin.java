package com.jay.cardboardvr.mixin;

import com.jay.cardboardvr.ScreenCompat;
import com.jay.cardboardvr.VrConfig;
import com.jay.cardboardvr.VrSettingsScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds "VR: ON/OFF" and "VR Settings" buttons to the title screen. */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Component title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void cardboardvr$addButtons(CallbackInfo ci) {
        int x = this.width / 2 + 104, y = this.height / 4 + 48;
        this.addRenderableWidget(Button.builder(
                Component.literal("VR: " + (VrConfig.I.vrEnabled ? "ON" : "OFF")), b -> {
                    VrConfig.I.vrEnabled = !VrConfig.I.vrEnabled;
                    VrConfig.save();
                    b.setMessage(Component.literal("VR: " + (VrConfig.I.vrEnabled ? "ON" : "OFF")));
                }).bounds(x, y, 80, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("VR Settings"),
                b -> ScreenCompat.open(Minecraft.getInstance(), new VrSettingsScreen(this)))
                .bounds(x, y + 24, 80, 20).build());
    }
}
