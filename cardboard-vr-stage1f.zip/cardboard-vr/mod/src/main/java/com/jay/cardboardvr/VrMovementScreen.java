package com.jay.cardboardvr;

import net.minecraft.client.gui.screens.Screen;

/** Tab 2: movement (mouse mode or gamepad mode). */
public class VrMovementScreen extends VrBaseScreen {
    static final float[] MSENS = {0.5f, 1f, 1.5f, 2f, 3f, 4f};
    static final float[] DEAD = {0.5f, 1f, 2f, 3f, 5f};

    public VrMovementScreen(Screen parent) {
        super(parent, 1, "Boardcraft VR - Movement");
    }

    @Override
    protected void init() {
        chrome();
        VrConfig c = VrConfig.I;
        int lx = width / 2 - 155, rx = width / 2 + 5, y = 36, s = 24;

        btn(lx, y, 310, () -> "Move with: " + (c.moveMode == 0 ? "Mouse" : "Gamepad"), () -> {
            c.moveMode = 1 - c.moveMode;
            rebuildWidgets();
        });
        if (c.moveMode == 0) {
            btn(lx, y + s, 150, () -> String.format("Walk sens: x%.1f", c.mouseSens), () -> c.mouseSens = next(MSENS, c.mouseSens));
            btn(lx, y + s * 2, 150, () -> String.format("Dead zone: %.1f", c.deadZone), () -> c.deadZone = next(DEAD, c.deadZone));
            btn(rx, y + s, 150, () -> "Invert left/right: " + onOff(c.invertX), () -> c.invertX = !c.invertX);
            btn(rx, y + s * 2, 150, () -> "Invert fwd/back: " + onOff(c.invertY), () -> c.invertY = !c.invertY);
            note(lx, y + s * 3, 310, "Mouse/joystick moves you, never the camera");
        } else {
            note(lx, y + s, 310, "Gamepad: map your stick to W A S D");
            note(lx, y + s * 2, 310, "in your launcher's gamepad settings");
            note(lx, y + s * 3, 310, "Mouse walking and mouse look are OFF");
        }
    }
}
