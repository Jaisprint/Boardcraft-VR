package com.jay.cardboardvr;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Tab 3: controls. Left = the physical button (click it, then press the button or any key).
 * Right = the Minecraft action it triggers (auto-filled from your Minecraft controls, or pick from the list).
 */
public class VrControlsScreen extends VrBaseScreen {
    static final String[] NAMES = {"Tap", "Back", "Vol Up", "Vol Down"};
    private int learning = -1, learnDelay = 0;
    private String note = "Vol Up + Vol Down together = Pause menu";
    private Button noteBtn;
    private final Button[] keyBtn = new Button[4];

    public VrControlsScreen(Screen parent) {
        super(parent, 2, "Boardcraft VR - Controls");
    }

    private String keyLabel(int i) {
        return learning == i ? NAMES[i] + ": press a button..." : NAMES[i] + ": " + KeyNames.label(VrConfig.I.codes[i]);
    }

    static boolean validKey(int k) {
        return k == 32 || k == 39 || (k >= 44 && k <= 57) || k == 59 || k == 61 || (k >= 65 && k <= 93)
                || k == 96 || k == 161 || k == 162 || (k >= 256 && k <= 269) || (k >= 280 && k <= 284)
                || (k >= 290 && k <= 314) || (k >= 320 && k <= 348);
    }

    @Override
    protected void init() {
        chrome();
        VrConfig c = VrConfig.I;
        int lx = width / 2 - 155, rx = width / 2 + 5, y = 36, s = 24;

        for (int i = 0; i < 4; i++) {
            final int k = i;
            keyBtn[i] = addRenderableWidget(Button.builder(Component.literal(keyLabel(i)), b -> {
                learning = k;
                learnDelay = 15;
                refresh();
            }).bounds(lx, y + s * i, 150, 20).build());
            addRenderableWidget(Button.builder(Component.literal(VrActions.label(c.acts[i])),
                    b -> minecraft.setScreenAndShow(new VrActionPickerScreen(this, k)))
                    .bounds(rx, y + s * i, 150, 20).build());
        }

        noteBtn = note(lx, y + s * 4 + 4, 310, note);
        addRenderableWidget(Button.builder(Component.literal("Reset to defaults"), b -> {
            c.resetBindings();
            VrConfig.save();
            learning = -1;
            note = "Bindings reset";
            rebuildWidgets();
        }).bounds(lx, y + s * 5 + 4, 150, 20).build());
    }

    private void refresh() {
        for (int i = 0; i < 4; i++) keyBtn[i].setMessage(Component.literal(keyLabel(i)));
        noteBtn.setMessage(Component.literal(note));
    }

    @Override
    public void tick() {
        super.tick();
        if (learning < 0) return;
        if (learnDelay > 0) { learnDelay--; return; }
        int found = 0;
        for (int k = 32; k <= 348 && found == 0; k++) {
            if (validKey(k) && InputHandler.poll(k)) found = k;
        }
        for (int m = 0; m <= 2 && found == 0; m++) {
            if (InputHandler.poll(1000 + m)) found = 1000 + m;
        }
        if (found == 0) return;

        VrConfig c = VrConfig.I;
        note = "Vol Up + Vol Down together = Pause menu";
        for (int j = 0; j < 4; j++) {
            if (j != learning && c.codes[j] == found) {
                c.codes[j] = 0;
                note = "Conflict: removed that button from " + NAMES[j];
            }
        }
        c.codes[learning] = found;

        // Show what Minecraft already does with this key (from the real Minecraft controls).
        String mcName = KeyNames.mc(found);
        if (mcName != null) {
            for (KeyMapping m : minecraft.options.keyMappings) {
                if (mcName.equals(m.saveString())) {
                    c.acts[learning] = m.getName();
                    note = NAMES[learning] + " = " + VrActions.label(m.getName());
                    break;
                }
            }
        }
        learning = -1;
        VrConfig.save();
        rebuildWidgets();
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return learning < 0;
    }
}
