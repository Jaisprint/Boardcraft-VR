# Cardboard VR - stage 1 (Minecraft 26.3 Fabric + gyro app)

Stage 1 = head tracking, mouse-walk, rebindable buttons, VR settings.
NOT included yet: stereo (two-eye) rendering, lens distortion, gaze reticle, floating HUD.
That part needs the 26.3 render code looked up first, so it comes after this builds.

## Build
Easiest (no PC): push this whole folder to a GitHub repo -> Actions tab builds both:
- `cardboardvr-mod` artifact -> the mod .jar
- `gyro-sender-apk` artifact -> the Android app .apk (debug-signed, installs normally)

Local mod build (JDK 25 + Gradle 9.3+): `cd mod && gradle build` -> `mod/build/libs/cardboardvr-0.1.0.jar`
(The Android app needs the Android SDK, so use GitHub Actions for it.)

## Install
1. Zalith: Fabric instance on 26.3. Put the mod jar + Fabric API (for 26.3) in its `mods` folder.
2. Install the APK, open it, press Start (allow notifications).
3. In Minecraft: title screen -> "VR: OFF" button (turns ON) / "VR Settings", or press F9 anywhere.
4. Settings screen shows "Gyro OK" when data arrives. Port must match in both (default 9876).

## Controls
- Head = look only. Recenter in settings.
- Mouse/joystick = walk only (left/right strafe, up/down fwd/back), follows where your head faces.
- Tap / Back / Vol Up / Vol Down: Controls... screen. Click a slot, then press the physical button
  to learn it. Defaults: Tap=Attack, Back=Use, Vol Up=Inventory, Vol Down=Jump,
  Vol Up + Vol Down together = Pause menu.
- Slots start "Not set": Tap and Back already work as left/right click through Minecraft/Zalith.
  Only bind them if you want something different.

## Known limits / untested
- Fixed after first real build (26.2+ API: setScreenAndShow, gui.screen(), LWJGL on compile classpath, title buttons via mixin). Further small fixes may still be needed.
- Back may still act as Esc if Zalith maps it that way; the mod can't block that yet.
- If volume keys don't show up in the learn screen, map them to keyboard keys in Zalith's controls.
- Android may stop sensors if the app is killed; keep the notification alive.
- Mouse look is overwritten by head tracking, so it may flicker slightly.
- Config file: `config/cardboardvr.json`.

## Future 6DoF
`TrackingProvider` is the seam: add a new provider for controllers; input/UI don't change.

## v1f changes
- Tabs: Tracking / Movement / Controls. Movement can be Mouse mode or Gamepad mode.
- Controls: click a physical button (Tap, Back, Vol Up, Vol Down), press it; the right side shows the
  Minecraft action for that key, or click it to pick any action from Minecraft's own controls list.
- Camera look is blocked while VR is ON (mixin + mouse sensitivity forced to 0, restored when VR is OFF).
  The status line shows "look-block N": if it stays 0 while you move the mouse, the mixin did not apply.
