package com.jay.cardboardvr;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.lwjgl.glfw.GLFW;

/** Mouse-walk, rebindable buttons, Vol Up + Vol Down pause combo, F9 hotkey. */
public class InputHandler {
    static final int VOL_UP = 2, VOL_DOWN = 3;
    static final int A_ATTACK = 1, A_USE = 2, A_JUMP = 3, A_INV = 4, A_PAUSE = 5;

    private static Minecraft MC;
    private static boolean f9Prev, prevOn, prevScreenNull = true, comboLatched, holdSet;
    private static double lastX, lastY;
    private static float vx, vy, holdYaw, holdPitch;
    private static final boolean[] walk = new boolean[4];
    private static final boolean[] down = new boolean[4];
    private static final boolean[] prevDown = new boolean[4];
    private static final boolean[] active = new boolean[4];

    static InputConstants.Key mouse(int b) { return InputConstants.Type.MOUSE.getOrCreate(b); }

    /** Uses only Minecraft's own input calls (raw GLFW polling crashes on Android launchers). */
    static boolean poll(com.mojang.blaze3d.platform.Window win, int code) {
        if (code >= 1000) {
            int b = code - 1000;
            if (b == 0) return MC.mouseHandler.isLeftPressed();
            if (b == 1) return MC.mouseHandler.isRightPressed();
            if (b == 2) return MC.mouseHandler.isMiddlePressed();
            return false;
        }
        return InputConstants.isKeyDown(win, code);
    }

    public static void tick(Minecraft mc) {
        MC = mc;
        VrConfig c = VrConfig.I;
        var win = mc.getWindow();
        Screen cur = ScreenCompat.current(mc);

        {
            boolean f9 = InputConstants.isKeyDown(win, GLFW.GLFW_KEY_F9);
            if (f9 && !f9Prev && !(cur instanceof VrSettingsScreen) && !(cur instanceof VrControlsScreen)) {
                ScreenCompat.open(mc, new VrSettingsScreen(cur));
            }
            f9Prev = f9;
        }

        boolean on = c.vrEnabled && mc.player != null;
        if (!on) {
            if (prevOn) releaseAll();
            prevOn = false;
            return;
        }
        if (!prevOn) {
            GyroReceiver.I.recenter = true;
            vx = 0; vy = 0; holdSet = false;
        }
        prevOn = true;

        boolean screenNull = cur == null;

        // Keep the camera from being turned by the mouse: head tracking owns the view.
        if (screenNull) {
            boolean fresh = c.tracking && GyroReceiver.I.isActive();
            if (fresh) {
                holdSet = false;
            } else if (!holdSet) {
                holdYaw = mc.player.getYRot();
                holdPitch = mc.player.getXRot();
                holdSet = true;
            } else {
                mc.player.setYRot(holdYaw);
                mc.player.setXRot(holdPitch);
            }
        }

        // Mouse -> walking
        double x = mc.mouseHandler.xpos(), y = mc.mouseHandler.ypos();
        double dx = x - lastX, dy = y - lastY;
        lastX = x; lastY = y;
        if (screenNull != prevScreenNull || Math.abs(dx) > 300 || Math.abs(dy) > 300) { dx = 0; dy = 0; }
        prevScreenNull = screenNull;

        if (screenNull) {
            float sx = c.invertX ? -1f : 1f, sy = c.invertY ? -1f : 1f;
            vx = vx * 0.5f + (float) dx * c.mouseSens * sx;
            vy = vy * 0.5f + (float) dy * c.mouseSens * sy;
            setWalk(0, -vy > c.deadZone);
            setWalk(1, -vy < -c.deadZone);
            setWalk(2, vx > c.deadZone);
            setWalk(3, vx < -c.deadZone);
        } else {
            vx = 0; vy = 0;
            for (int i = 0; i < 4; i++) setWalk(i, false);
        }

        // Buttons
        for (int i = 0; i < 4; i++) down[i] = c.codes[i] != 0 && poll(win, c.codes[i]);

        boolean both = c.codes[VOL_UP] != 0 && c.codes[VOL_DOWN] != 0 && down[VOL_UP] && down[VOL_DOWN];
        if (both && !comboLatched) {
            comboLatched = true;
            cancel(VOL_UP, c);
            cancel(VOL_DOWN, c);
            pause(mc);
        }
        if (!down[VOL_UP] && !down[VOL_DOWN]) comboLatched = false;

        for (int i = 0; i < 4; i++) {
            if (comboLatched && (i == VOL_UP || i == VOL_DOWN)) { prevDown[i] = down[i]; continue; }
            int act = c.actions[i];
            if (down[i] && !prevDown[i]) {
                active[i] = true;
                begin(mc, act);
            }
            if (!down[i] && prevDown[i] && active[i]) {
                active[i] = false;
                end(mc, act);
            }
            prevDown[i] = down[i];
        }
    }

    static KeyMapping walkMap(int i) {
        var o = MC.options;
        return i == 0 ? o.keyUp : i == 1 ? o.keyDown : i == 2 ? o.keyRight : o.keyLeft;
    }

    static void setWalk(int i, boolean want) {
        if (MC == null) return;
        if (want != walk[i]) {
            walk[i] = want;
            walkMap(i).setDown(want);
        }
    }

    static void cancel(int i, VrConfig c) {
        if (active[i]) {
            setAction(c.actions[i], false);
            active[i] = false;
        }
    }

    static void begin(Minecraft mc, int act) {
        if (act == A_PAUSE) { pause(mc); return; }
        if (act == A_ATTACK || act == A_USE || act == A_JUMP) {
            if (ScreenCompat.current(mc) == null) setAction(act, true);
        }
    }

    static void end(Minecraft mc, int act) {
        if (act == A_INV) { inventory(mc); return; }
        setAction(act, false);
    }

    static void setAction(int act, boolean d) {
        if (MC == null) return;
        var o = MC.options;
        switch (act) {
            case A_ATTACK -> { o.keyAttack.setDown(d); if (d) KeyMapping.click(mouse(0)); }
            case A_USE -> { o.keyUse.setDown(d); if (d) KeyMapping.click(mouse(1)); }
            case A_JUMP -> o.keyJump.setDown(d);
            default -> { }
        }
    }

    static void inventory(Minecraft mc) {
        Screen cur = ScreenCompat.current(mc);
        if (cur == null) {
            KeyMapping.click(mc.options.keyInventory.getDefaultKey());
        } else if (cur instanceof AbstractContainerScreen<?> && mc.player != null) {
            mc.player.closeContainer();
        }
    }

    static void pause(Minecraft mc) {
        Screen cur = ScreenCompat.current(mc);
        if (cur == null) ScreenCompat.open(mc, new PauseScreen(true));
        else if (cur instanceof PauseScreen) ScreenCompat.open(mc, null);
    }

    static void releaseAll() {
        for (int i = 0; i < 4; i++) {
            setWalk(i, false);
            if (active[i]) { setAction(VrConfig.I.actions[i], false); active[i] = false; }
            prevDown[i] = false;
            down[i] = false;
        }
        comboLatched = false;
        vx = 0; vy = 0;
    }
}
