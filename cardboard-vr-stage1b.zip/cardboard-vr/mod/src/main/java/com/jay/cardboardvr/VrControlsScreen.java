package com.jay.cardboardvr;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class VrControlsScreen extends Screen {
    private final Screen parent;
    private int learning = -1, learnDelay = 0;
    private String note = "Vol Up + Vol Down together = Pause menu";
    private Button noteBtn;
    private final Button[] keyBtn = new Button[4];

    static final String[] NAMES = {"Tap", "Back", "Vol Up", "Vol Down"};
    static final String[] ACTS = {"None", "Attack", "Use/Place", "Jump", "Inventory", "Pause menu"};

    public VrControlsScreen(Screen parent) {
        super(Component.literal("VR Controls"));
        this.parent = parent;
    }

    static String keyName(int code) {
        if (code == 0) return "Not set";
        if (code >= 1000) return "Mouse " + (code - 1000);
        if (code == 256) return "Esc";
        if (code == 32) return "Space";
        return "Key " + code;
    }

    static boolean validKey(int k) {
        return k == 32 || k == 39 || (k >= 44 && k <= 57) || k == 59 || k == 61 || (k >= 65 && k <= 93)
                || k == 96 || k == 161 || k == 162 || (k >= 256 && k <= 269) || (k >= 280 && k <= 284)
                || (k >= 290 && k <= 314) || (k >= 320 && k <= 348);
    }

    private String label(int i) {
        return learning == i ? NAMES[i] + ": press a button..." : NAMES[i] + ": " + keyName(VrConfig.I.codes[i]);
    }

    @Override
    protected void init() {
        VrConfig c = VrConfig.I;
        int lx = width / 2 - 155, rx = width / 2 + 5, y = 36, s = 24;

        addRenderableWidget(Button.builder(Component.literal("VR Controls"), b -> {})
                .bounds(lx, 8, 310, 20).build()).active = false;

        for (int i = 0; i < 4; i++) {
            final int k = i;
            keyBtn[i] = addRenderableWidget(Button.builder(Component.literal(label(i)), b -> {
                learning = k;
                learnDelay = 15;
                refresh();
            }).bounds(lx, y + s * i, 150, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Does: " + ACTS[c.actions[i]]), b -> {
                c.actions[k] = (c.actions[k] + 1) % ACTS.length;
                VrConfig.save();
                b.setMessage(Component.literal("Does: " + ACTS[c.actions[k]]));
            }).bounds(rx, y + s * i, 150, 20).build());
        }

        noteBtn = addRenderableWidget(Button.builder(Component.literal(note), b -> {})
                .bounds(lx, y + s * 4 + 4, 310, 20).build());
        noteBtn.active = false;

        addRenderableWidget(Button.builder(Component.literal("Reset to defaults"), b -> {
            c.resetBindings();
            VrConfig.save();
            learning = -1;
            note = "Bindings reset";
            rebuildWidgets();
        }).bounds(lx, y + s * 5 + 4, 150, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(rx, y + s * 5 + 4, 150, 20).build());
    }

    private void refresh() {
        for (int i = 0; i < 4; i++) keyBtn[i].setMessage(Component.literal(label(i)));
        noteBtn.setMessage(Component.literal(note));
    }

    @Override
    public void tick() {
        super.tick();
        if (learning < 0) return;
        if (learnDelay > 0) { learnDelay--; return; }
        long win = GLFW.glfwGetCurrentContext();
        if (win == 0) return;
        int found = 0;
        for (int k = 32; k <= 348 && found == 0; k++) {
            if (validKey(k) && GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS) found = k;
        }
        for (int m = 0; m <= 7 && found == 0; m++) {
            if (GLFW.glfwGetMouseButton(win, m) == GLFW.GLFW_PRESS) found = 1000 + m;
        }
        if (found != 0) {
            VrConfig c = VrConfig.I;
            note = "Vol Up + Vol Down together = Pause menu";
            for (int j = 0; j < 4; j++) {
                if (j != learning && c.codes[j] == found) {
                    c.codes[j] = 0;
                    note = "Conflict: removed that button from " + NAMES[j];
                }
            }
            c.codes[learning] = found;
            learning = -1;
            VrConfig.save();
            refresh();
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return learning < 0;
    }

    @Override
    public void onClose() {
        VrConfig.save();
        minecraft.setScreenAndShow(parent);
    }
}
