# Cardboard VR - stage 1 (Minecraft 26.3 Fabric + gyro app)

Stage 1 = head tracking, mouse-walk, rebindable buttons, VR settings.
NOT included yet: stereo (two-eye) rendering, lens distortion, gaze reticle, floating HUD.
That part needs the 26.3 render code looked up first, so it comes after this builds.

## Build
Easiest (no PC): push this whole folder to a GitHub repo -> Actions tab builds both:
- `cardboardvr-mod` artifact -> the mod .jar
- `gyro-sender-apk` artifact -> the Android app .apk (debug-signed, installs normally)

Local mod build (JDK 25 + Gradle 9.3+): `cd mod && gradle build` -> `mod/build/libs/cardboardvr-0.1.0.jar`
(The Android app needs the Android SDK, so use GitHub Actions for it.)

## Install
1. Zalith: Fabric instance on 26.3. Put the mod jar + Fabric API (for 26.3) in its `mods` folder.
2. Install the APK, open it, press Start (allow notifications).
3. In Minecraft: title screen -> "VR: OFF" button (turns ON) / "VR Settings", or press F9 anywhere.
4. Settings screen shows "Gyro OK" when data arrives. Port must match in both (default 9876).

## Controls
- Head = look only. Recenter in settings.
- Mouse/joystick = walk only (left/right strafe, up/down fwd/back), follows where your head faces.
- Tap / Back / Vol Up / Vol Down: Controls... screen. Click a slot, then press the physical button
  to learn it. Defaults: Tap=Attack, Back=Use, Vol Up=Inventory, Vol Down=Jump,
  Vol Up + Vol Down together = Pause menu.
- Slots start "Not set": Tap and Back already work as left/right click through Minecraft/Zalith.
  Only bind them if you want something different.

## Known limits / untested
- Fixed after first real build (26.2+ API: setScreenAndShow, gui.screen(), LWJGL on compile classpath, title buttons via mixin). Further small fixes may still be needed.
- Back may still act as Esc if Zalith maps it that way; the mod can't block that yet.
- If volume keys don't show up in the learn screen, map them to keyboard keys in Zalith's controls.
- Android may stop sensors if the app is killed; keep the notification alive.
- Mouse look is overwritten by head tracking, so it may flicker slightly.
- Config file: `config/cardboardvr.json`.

## Future 6DoF
`TrackingProvider` is the seam: add a new provider for controllers; input/UI don't change.

## v1f changes
- Tabs: Tracking / Movement / Controls. Movement can be Mouse mode or Gamepad mode.
- Controls: click a physical button (Tap, Back, Vol Up, Vol Down), press it; the right side shows the
  Minecraft action for that key, or click it to pick any action from Minecraft's own controls list.
- Camera look is blocked while VR is ON (mixin + mouse sensitivity forced to 0, restored when VR is OFF).
  The status line shows "look-block N": if it stays 0 while you move the mouse, the mixin did not apply.

## v1g changes
- One settings screen split into titled sections (Head Tracking / Movement / Controls); scroll with the ^ and v buttons.
- VR mode popup: ON (also menus) / OFF / World only. Title screen button and settings button open it.
- "VR Settings" button on the pause menu (right of the main button column).
- Camera stutter fix: old rotation is kept equal to the new one (Minecraft interpolates between them every frame).
- Binding: click a key slot, let go, press any key or mouse button (left click works). Action list scrolls.

## v1h changes
- Icons: one cardboard icon on the title screen (grey = VR off, green = VR on) opens the VR settings.
  Pause menu uses the same icon with a small gear. Sprites are 16x16 in assets/cardboardvr/textures/gui/sprites/.
- The VR mode button (ON / OFF / World only popup) is pinned at the top of the settings screen, never scrolls away.

## v1i changes
- Pause-menu VR icon sits at the end of the row of small icon buttons.
- Mouse wheel scrolls the VR settings and the action list (the ^ / v buttons still work).

## v2a changes
- Head pose is applied once per frame on the render thread (MinecraftFrameMixin), so both stereo eyes see the same pose.
- Yaw no longer flips when looking straight down/up (uses the phone's up axis; needs the new 6-value gyro packet).
- StereoCraft bridge: Boardcraft switches StereoCraft to SBS_FULL and sets IPD / depth plane itself (Stereo View section).
- Mouse-walk uses 8-way sectors so a slightly off-axis stick no longer strafes randomly.
- Gyro app GyroService: send "fx,fy,fz,ux,uy,uz" (see chat). The old 3-value packet still works.

## v2b changes (viewer QR) - UNTESTED, nothing compiled
- Gyro app: "Scan viewer QR" button (zxing-android-embedded, camera permission). Decodes the Cardboard DeviceParams protobuf from the link's `?p=` (follows redirects for short links), saves it, and sends it to the mod as a "VP1" text packet (once right away, then every ~2 s while the sender runs).
- Gyro app now really sends the 6-value packet (look + phone x axis) that the v2a pole-flip fix needs. The 2a zip still had the old 3-value sender.
- Mod: viewer lens gap becomes the StereoCraft IPD (toggle "Use viewer IPD"). Screen-to-lens, tray, FOV angles and distortion coefficients are stored in config for 2c. New "Viewer" section in settings with "Forget viewer".

## v2c changes (lens distortion) - UNTESTED, nothing compiled
- New `DistortionPass` + `DistortionMixin`: right before Minecraft blits the finished frame, the SBS frame is copied and redrawn through a shader (Cardboard model p' = t(1 + k1 r^2 + k2 r^4), lens centre from the viewer's lens gap / tray distance / alignment, black outside the image). Only runs when: viewer is set, "Lens distortion" is ON, and StereoCraft is in SBS_FULL.
- Source FOV comes from Minecraft's FOV option (assumes a centred per-eye frustum; StereoCraft's convergence shear is ignored, it is ~1%).
- Pixels -> mm needs the physical screen size: new "Screen: x in" setting (diagonal, default 6.4). "Lens height: flipped" is for a phone held rotated 180 degrees.
- Pass touches raw GL and restores everything it changed. If it throws once it switches itself off for the session (see latest.log: "Lens distortion failed").
- Not in 2c yet: first-person hand cut-off fix, per-eye FOV tuning beyond this.
- 2c tweak: "Strength" setting (0-125%) scales k1/k2 so the distortion can be dialled down if the viewer's numbers look too strong.
