package com.jay.cardboardvr;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CardboardVrClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("cardboardvr");

    @Override
    public void onInitializeClient() {
        VrConfig.load();
        GyroReceiver.I.start(VrConfig.I.port);
        ClientTickEvents.END_CLIENT_TICK.register(InputHandler::tick);
        LOG.info("Cardboard VR loaded (port {}).", VrConfig.I.port);
        LOG.info("WARNING: YOU ARE USING A UNRELEASED APLHA VERSION EXPECT BUGS AND INCOMPLETE FEATURES!");
        LOG.info("Mod BoardCraftVR/CardboardVR is made by Jaisprint, But some of its features such as SBS Rendering is made from the mod StreoCraft All credits goes to them for the backend renderer!");
    }
}
