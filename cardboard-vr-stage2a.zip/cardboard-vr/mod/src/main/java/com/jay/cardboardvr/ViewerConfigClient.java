
package com.jay.cardboardvr;

import net.fabricmc.api.ClientModInitializer;

public class ViewerConfigClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        boolean loaded = CardboardViewerConfig.load();

        if (loaded) {
            CardboardVrClient.LOG.info(
                    "Cardboard viewer configuration loaded. IPD: {} mm!",
                    VrConfig.I.ipdMm);
        } else {
            CardboardVrClient.LOG.info(
                    "No saved Cardboard viewer configuration found. Try saving a new viewer pram through the Minecraft Cardboard VR app! ");
        }

        ViewerConfigReceiver.start();
    }
}
