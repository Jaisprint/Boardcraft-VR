
package com.jay.cardboardvr;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;

public final class ViewerConfigReceiver {
    public static final int PORT = 9877;

    private static DatagramSocket socket;
    public static volatile boolean bound = false;
    public static volatile long lastReceivedMs = 0;

    private ViewerConfigReceiver() {}

    public static synchronized void start() {
        stop();

        try {
            socket = new DatagramSocket(
                    new InetSocketAddress(
                            InetAddress.getLoopbackAddress(), PORT));

            socket.setSoTimeout(500);
            bound = true;

        } catch (Exception e) {
            CardboardVrClient.LOG.error(
                    "Could not start viewer configuration receiver", e);
            socket = null;
            bound = false;
            return;
        }

        DatagramSocket activeSocket = socket;

        Thread thread = new Thread(
                () -> receiveLoop(activeSocket),
                "cardboardvr-viewer-config");

        thread.setDaemon(true);
        thread.start();

        CardboardVrClient.LOG.info(
                "Cardboard viewer configuration receiver listening on {}", PORT);
    }

    public static synchronized void stop() {
        if (socket != null) {
            socket.close();
        }

        socket = null;
        bound = false;
    }

    private static void receiveLoop(DatagramSocket activeSocket) {
        byte[] buffer = new byte[8192];

        while (!activeSocket.isClosed()) {
            try {
                DatagramPacket packet =
                        new DatagramPacket(buffer, buffer.length);

                activeSocket.receive(packet);

                String message = new String(
                        packet.getData(),
                        packet.getOffset(),
                        packet.getLength(),
                        StandardCharsets.UTF_8
                ).trim();

                handle(message);

            } catch (SocketTimeoutException ignored) {
            } catch (Exception e) {
                if (!activeSocket.isClosed()) {
                    CardboardVrClient.LOG.warn(
                            "Viewer configuration packet error", e);
                }
            }
        }
    }

    private static void handle(String message) {
        final String prefix = "CBVR1:";

        if (!message.startsWith(prefix)) {
            return;
        }

        String payload = message.substring(prefix.length()).trim();

        try {
            CardboardViewerConfig.accept(payload);
            lastReceivedMs = System.currentTimeMillis();

        } catch (Exception e) {
            CardboardVrClient.LOG.warn(
                    "Rejected Cardboard viewer configuration", e);
        }
    }
}
