
package com.jay.cardboardvr;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;

public class CardboardViewerConfig {
    public String vendor = "";
    public String model = "";

    public float screenToLensMeters;
    public float interLensMeters;
    public float trayToLensMeters;

    public float[] fovAngles = new float[0];
    public float[] distortion = new float[0];

    public int verticalAlignment;
    public int primaryButton;

    private static final Gson GSON =
            new GsonBuilder().setPrettyPrinting().create();

    private static CardboardViewerConfig current;

    public static Path path() {
        return FabricLoader.getInstance()
                .getConfigDir()
                .resolve("cardboardvr-viewer.json");
    }

    public static synchronized CardboardViewerConfig get() {
        return current;
    }

    public static synchronized boolean load() {
        try {
            Path p = path();

            if (!Files.exists(p)) {
                current = null;
                return false;
            }

            CardboardViewerConfig config =
                    GSON.fromJson(Files.readString(p), CardboardViewerConfig.class);

            if (config == null || !config.valid()) {
                throw new IllegalArgumentException("Invalid saved viewer configuration");
            }

            current = config;
            applyRuntimeSettings();

            return true;
        } catch (Exception e) {
            CardboardVrClient.LOG.warn(
                    "Could not load Cardboard viewer configuration", e);
            current = null;
            return false;
        }
    }

    public synchronized void save() throws IOException {
        Files.createDirectories(path().getParent());
        Files.writeString(path(), GSON.toJson(this));
    }

    public static synchronized void accept(String encoded) throws Exception {
        if (encoded == null || encoded.isBlank()) {
            throw new IllegalArgumentException("Empty viewer payload");
        }

        byte[] bytes = Base64.getUrlDecoder().decode(encoded);

        if (bytes.length == 0 || bytes.length > 65536) {
            throw new IllegalArgumentException("Invalid viewer payload size");
        }

        CardboardViewerConfig config = parse(bytes);

        if (!config.valid()) {
            throw new IllegalArgumentException("Invalid viewer parameters");
        }

        config.save();

        current = config;
        applyRuntimeSettings();

        CardboardVrClient.LOG.info(
                "Loaded Cardboard viewer: {} {}", config.vendor, config.model);
    }

    private static void applyRuntimeSettings() {
        CardboardViewerConfig config = current;

        if (config == null) return;

        // Keep the viewer parameters in their own JSON file.
        // This only updates the runtime IPD used by the existing StereoBridge.
        VrConfig.I.ipdMm = config.interLensMeters * 1000f;
    }

    public boolean valid() {
        if (!Float.isFinite(screenToLensMeters)
                || !Float.isFinite(interLensMeters)
                || !Float.isFinite(trayToLensMeters)
                || screenToLensMeters <= 0
                || interLensMeters <= 0
                || trayToLensMeters < 0) {
            return false;
        }

        if (fovAngles == null) fovAngles = new float[0];
        if (distortion == null) distortion = new float[0];

        if (fovAngles.length != 0 && fovAngles.length != 4) {
            return false;
        }

        for (float angle : fovAngles) {
            if (!Float.isFinite(angle) || angle <= 0 || angle >= 180) {
                return false;
            }
        }

        for (float coefficient : distortion) {
            if (!Float.isFinite(coefficient)) return false;
        }

        return true;
    }

    private static CardboardViewerConfig parse(byte[] data) {
        CardboardViewerConfig result = new CardboardViewerConfig();
        ProtoReader reader = new ProtoReader(data);

        ArrayList<Float> fov = new ArrayList<>();
        ArrayList<Float> distortion = new ArrayList<>();

        while (!reader.atEnd()) {
            long tag = reader.readVarint();

            if (tag == 0) break;

            int field = (int) (tag >>> 3);
            int wire = (int) (tag & 7);

            switch (field) {
                case 1:
                    if (wire == 2) result.vendor = reader.readString();
                    else reader.skip(wire);
                    break;

                case 2:
                    if (wire == 2) result.model = reader.readString();
                    else reader.skip(wire);
                    break;

                case 3:
                    if (wire == 5) result.screenToLensMeters = reader.readFloat();
                    else reader.skip(wire);
                    break;

                case 4:
                    if (wire == 5) result.interLensMeters = reader.readFloat();
                    else reader.skip(wire);
                    break;

                case 5:
                    readFloats(reader, wire, fov);
                    break;

                case 6:
                    if (wire == 5) result.trayToLensMeters = reader.readFloat();
                    else reader.skip(wire);
                    break;

                case 7:
                    readFloats(reader, wire, distortion);
                    break;

                case 11:
                    if (wire == 0) result.verticalAlignment =
                            (int) reader.readVarint();
                    else reader.skip(wire);
                    break;

                case 12:
                    if (wire == 0) result.primaryButton =
                            (int) reader.readVarint();
                    else reader.skip(wire);
                    break;

                default:
                    reader.skip(wire);
                    break;
            }
        }

        result.fovAngles = toArray(fov);
        result.distortion = toArray(distortion);

        return result;
    }

    private static float[] toArray(ArrayList<Float> values) {
        float[] result = new float[values.size()];

        for (int i = 0; i < values.size(); i++) {
            result[i] = values.get(i);
        }

        return result;
    }

    private static void readFloats(
            ProtoReader reader, int wire, ArrayList<Float> output) {

        if (wire == 5) {
            output.add(reader.readFloat());
        } else if (wire == 2) {
            byte[] packed = reader.readBytes();

            if ((packed.length & 3) != 0) {
                throw new IllegalArgumentException("Invalid packed float data");
            }

            ByteBuffer buffer = ByteBuffer.wrap(packed)
                    .order(ByteOrder.LITTLE_ENDIAN);

            while (buffer.remaining() >= 4) {
                output.add(buffer.getFloat());
            }
        } else {
            reader.skip(wire);
        }
    }

    private static final class ProtoReader {
        private final byte[] data;
        private int position;

        ProtoReader(byte[] data) {
            this.data = data;
        }

        boolean atEnd() {
            return position >= data.length;
        }

        long readVarint() {
            long value = 0;
            int shift = 0;

            while (shift < 64) {
                if (position >= data.length) {
                    throw new IllegalArgumentException("Truncated protobuf");
                }

                int b = data[position++] & 0xff;
                value |= (long) (b & 0x7f) << shift;

                if ((b & 0x80) == 0) return value;

                shift += 7;
            }

            throw new IllegalArgumentException("Invalid protobuf varint");
        }

        float readFloat() {
            if (position + 4 > data.length) {
                throw new IllegalArgumentException("Truncated float");
            }

            int bits = (data[position] & 0xff)
                    | ((data[position + 1] & 0xff) << 8)
                    | ((data[position + 2] & 0xff) << 16)
                    | ((data[position + 3] & 0xff) << 24);

            position += 4;
            return Float.intBitsToFloat(bits);
        }

        byte[] readBytes() {
            long length = readVarint();

            if (length < 0 || length > data.length - position) {
                throw new IllegalArgumentException("Invalid protobuf length");
            }

            int count = (int) length;
            byte[] result = new byte[count];

            System.arraycopy(data, position, result, 0, count);
            position += count;

            return result;
        }

        String readString() {
            return new String(readBytes(), java.nio.charset.StandardCharsets.UTF_8);
        }

        void skip(int wire) {
            switch (wire) {
                case 0:
                    readVarint();
                    break;

                case 1:
                    advance(8);
                    break;

                case 2:
                    long length = readVarint();

                    if (length < 0 || length > Integer.MAX_VALUE) {
                        throw new IllegalArgumentException("Invalid field length");
                    }

                    advance((int) length);
                    break;

                case 5:
                    advance(4);
                    break;

                default:
                    throw new IllegalArgumentException("Unsupported wire type " + wire);
            }
        }

        private void advance(int count) {
            if (count < 0 || count > data.length - position) {
                throw new IllegalArgumentException("Truncated protobuf field");
            }

            position += count;
        }
    }
}
