package com.jay.gyrosender;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private EditText portE;
    private Button btn;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp = getSharedPreferences("gyro", MODE_PRIVATE);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(48, 96, 48, 48);

        TextView title = new TextView(this);
        title.setText("Cardboard Gyro Sender");
        title.setTextSize(24);
        l.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Port must match the port in the Minecraft mod's VR Settings (default 9876).");
        l.addView(hint);

        portE = new EditText(this);
        portE.setInputType(InputType.TYPE_CLASS_NUMBER);
        portE.setText(String.valueOf(sp.getInt("port", 9876)));
        l.addView(portE);

        btn = new Button(this);
        l.addView(btn);

        status = new TextView(this);
        status.setTextSize(18);
        l.addView(status);

        setContentView(l);

        btn.setOnClickListener(v -> {
            if (GyroService.running) {
                stopService(new Intent(this, GyroService.class));
            } else {
                int port = 9876;
                try { port = Integer.parseInt(portE.getText().toString().trim()); } catch (Exception ignored) {}
                if (port < 1024 || port > 65535) port = 9876;
                sp.edit().putInt("port", port).apply();
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                }
                Intent i = new Intent(this, GyroService.class).putExtra("port", port);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            }
            btn.postDelayed(this::refresh, 400);
        });
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        boolean r = GyroService.running;
        btn.setText(r ? "Stop" : "Start");
        status.setText(r ? "Running. Now open Minecraft." : "Stopped.");
    }
}
