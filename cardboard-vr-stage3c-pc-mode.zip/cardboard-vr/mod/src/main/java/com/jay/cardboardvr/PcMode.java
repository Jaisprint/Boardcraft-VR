package com.jay.cardboardvr;

import java.util.Locale;
import java.util.Map;

/**
 * PC mode: used automatically when the game is NOT running on a phone launcher (Zalith / Pojav / Android).
 * Head tracking is simulated with the mouse (menus: mouse moves the head, crosshair = pointer, left click = Tap;
 * in the world: normal mouse look). Everything else (stereo, distortion, floating menus) stays the same.
 * VrConfig.pcMode: 0 = Auto, 1 = force PC mode, 2 = force phone mode.
 */
public final class PcMode {
    private static Boolean detected;
    private static String why = "";

    private PcMode() {}

    public static boolean active() {
        int m = VrConfig.I.pcMode;
        if (m == 1) return true;
        if (m == 2) return false;
        return detectedPc();
    }

    public static boolean detectedPc() {
        if (detected == null) detected = detect();
        return detected;
    }

    public static String label() {
        int m = VrConfig.I.pcMode;
        String s = m == 0 ? "Auto" : m == 1 ? "ON" : "OFF";
        return "PC mode: " + s + (m == 0 ? (detectedPc() ? " (PC)" : " (phone)") : "");
    }

    public static String reason() { return why; }

    private static boolean detect() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        String home = System.getProperty("user.home", "") + "|" + System.getProperty("user.dir", "") + "|"
                + System.getProperty("java.home", "");
        String h = home.toLowerCase(Locale.ROOT);
        if (os.contains("android")) return no("os.name is Android");
        try {
            for (Map.Entry<String, String> e : System.getenv().entrySet()) {
                String k = e.getKey().toUpperCase(Locale.ROOT);
                if (k.startsWith("POJAV") || k.startsWith("ZALITH")) return no("launcher env " + e.getKey());
            }
        } catch (Throwable ignored) { }
        for (Object k : System.getProperties().keySet()) {
            String s = String.valueOf(k).toLowerCase(Locale.ROOT);
            if (s.startsWith("pojav") || s.startsWith("zalith")) return no("launcher property " + k);
        }
        if (h.contains("/data/user/") || h.contains("/data/data/") || h.contains("/storage/emulated")
                || h.contains("pojav") || h.contains("zalith") || h.contains("movtery")) return no("Android path");
        why = "desktop OS (" + os + ")";
        return true;
    }

    private static boolean no(String r) {
        why = r;
        return false;
    }
}
