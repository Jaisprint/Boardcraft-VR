package com.jay.cardboardvr.mixin;

import com.jay.cardboardvr.FloatingMenu;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * TitleScreen overrides extractRenderState and draws extra things around the super call. Wrapping its own override
 * keeps those on the floating panel too. FloatingMenu ignores a nested begin, so there is no double transform.
 * Full descriptor + require = 0: a changed method just means no match, never a crash.
 */
@Mixin(TitleScreen.class)
public abstract class TitleDrawMixin {
    private static final String D = "extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIF)V";

    @Inject(method = D, at = @At("HEAD"), require = 0)
    private void cardboardvr$begin(GuiGraphicsExtractor g, int mx, int my, float pt, CallbackInfo ci) {
        FloatingMenu.begin((Screen) (Object) this, g);
    }

    @Inject(method = D, at = @At("TAIL"), require = 0)
    private void cardboardvr$end(GuiGraphicsExtractor g, int mx, int my, float pt, CallbackInfo ci) {
        FloatingMenu.end((Screen) (Object) this, g);
    }
}
