package com.jay.cardboardvr.mixin;

import com.jay.cardboardvr.FloatingMenu;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Puts the whole screen on the floating panel. Every target gives its FULL descriptor, so if Minecraft renames or
 * changes one of these methods the hook simply does not match (require = 0) instead of breaking the game.
 *
 *  - extractRenderStateWithTooltipAndSubtitles: outermost wrapper, covers everything incl. tooltips (preferred).
 *  - extractRenderState: inner fallback; FloatingMenu ignores it when the outer wrapper already pushed the panel.
 *  - extractBackground: drawn untransformed, or skipped for in-world menus (no dim/blur, you see the world).
 */
@Mixin(Screen.class)
public abstract class ScreenDrawMixin {
    private static final String D = "(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIF)V";

    @Inject(method = "extractRenderStateWithTooltipAndSubtitles" + D, at = @At("HEAD"), require = 0)
    private void cardboardvr$outerBegin(GuiGraphicsExtractor g, int mx, int my, float pt, CallbackInfo ci) {
        FloatingMenu.begin((Screen) (Object) this, g);
    }

    @Inject(method = "extractRenderStateWithTooltipAndSubtitles" + D, at = @At("TAIL"), require = 0)
    private void cardboardvr$outerEnd(GuiGraphicsExtractor g, int mx, int my, float pt, CallbackInfo ci) {
        FloatingMenu.end((Screen) (Object) this, g);
    }

    @Inject(method = "extractRenderState" + D, at = @At("HEAD"), require = 0)
    private void cardboardvr$innerBegin(GuiGraphicsExtractor g, int mx, int my, float pt, CallbackInfo ci) {
        FloatingMenu.begin((Screen) (Object) this, g);
    }

    @Inject(method = "extractRenderState" + D, at = @At("TAIL"), require = 0)
    private void cardboardvr$innerEnd(GuiGraphicsExtractor g, int mx, int my, float pt, CallbackInfo ci) {
        FloatingMenu.end((Screen) (Object) this, g);
    }

    @Inject(method = "extractBackground" + D, at = @At("HEAD"), cancellable = true, require = 0)
    private void cardboardvr$bgBegin(GuiGraphicsExtractor g, int mx, int my, float pt, CallbackInfo ci) {
        if (FloatingMenu.hideBackground((Screen) (Object) this)) { ci.cancel(); return; }
        FloatingMenu.bgBegin(g);
    }

    @Inject(method = "extractBackground" + D, at = @At("TAIL"), require = 0)
    private void cardboardvr$bgEnd(GuiGraphicsExtractor g, int mx, int my, float pt, CallbackInfo ci) {
        FloatingMenu.bgEnd(g);
    }
}
