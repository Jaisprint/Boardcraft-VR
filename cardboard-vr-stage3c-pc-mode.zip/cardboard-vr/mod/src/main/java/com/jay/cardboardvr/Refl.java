package com.jay.cardboardvr;

import java.lang.reflect.Method;

/** Tiny reflection helper: call a no-argument method by name (used where a rename should not break the build). */
final class Refl {
    private Refl() {}

    static Object call(Object o, String name) throws Exception {
        if (o == null) return null;
        for (Class<?> k = o.getClass(); k != null; k = k.getSuperclass()) {
            for (Method m : k.getDeclaredMethods()) {
                if (m.getName().equals(name) && m.getParameterCount() == 0) {
                    m.setAccessible(true);
                    return m.invoke(o);
                }
            }
        }
        return null;
    }
}
