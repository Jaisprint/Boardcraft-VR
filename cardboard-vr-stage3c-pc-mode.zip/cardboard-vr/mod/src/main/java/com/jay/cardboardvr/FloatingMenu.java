package com.jay.cardboardvr;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fStack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Floating, world-locked menus (like Vivecraft's).
 *
 * The whole screen is treated as ONE flat panel hanging in space in front of you. When a screen opens the panel is
 * placed where you are looking. After that it stays put: turning your head moves you across it, the round crosshair
 * in the middle of the view is your pointer.
 *
 * How it works (per frame, frame()):
 *  1. Head direction -> where the view centre hits the panel plane (gaze point, in GUI pixels of the screen).
 *  2. Real projection of the panel at that point -> a 2x3 matrix (position, scale, foreshortening, keystone shear).
 *     The matrix is exact at the crosshair, so what you see under the crosshair is what is picked.
 *  3. The mouse cursor of Minecraft is set to the gaze point, so vanilla hover, clicks and tooltips all land on the
 *     widget under the crosshair. Tap (left click) just works.
 *  4. ScreenDrawMixin pushes the matrix around the screen drawing (begin/end), so the real vanilla widgets are drawn
 *     on the panel. The background (dim/blur) is drawn untransformed or removed (pause menu in a world).
 *
 * The panel is leashed: if you turn far away from it, it is dragged along so you never lose it.
 * If anything needed is missing (pose matrix, mouse fields) the menu falls back to the normal flat screen.
 */
public class FloatingMenu {
    // ---------- tuning ----------
    static final float LEASH_YAW = 38f;      // degrees you may turn away before the panel is dragged along
    static final float LEASH_PITCH = 26f;
    static final float MIN_FACING = 0.2f;    // cos of the max angle between gaze and panel normal

    // ---------- state ----------
    private static Screen screen;            // the screen that owns the current anchor
    private static boolean haveAnchor, active;
    private static float anchorYaw, anchorPitch;
    private static float gx, gy;             // gaze point on the panel, GUI pixels
    private static final float[] M = new float[6];   // m00 m01 m10 m11 tx ty  (screen = M * panel)
    private static float ringA;
    private static long lastDrawNs;
    private static int nest;                 // nested begin() calls (outer wrapper + inner/override hooks)
    private static int bgDepth;

    public static volatile int drawHits = 0;
    public static volatile long panoHitMs = 0;
    private static volatile long panoFallbackMs = 0;
    private static String problem = "";
    private static boolean logged;
    private static Object panoObj;
    private static Field spinF;

    // reflection (kept soft so a renamed method degrades the feature instead of breaking the build)
    private static boolean reflTried;
    private static Method mPose, mWin, mGetScreenW, mGetScreenH, mGetGuiW, mGetGuiH;
    private static Field fXpos, fYpos;

    // ---------- when is it on ----------

    /** Title screen needs VR mode ON. Every other screen: VR ON, or World only while a world is loaded. */
    public static boolean eligible(Minecraft mc, Screen s) {
        VrConfig c = VrConfig.I;
        boolean pc = PcMode.active();
        if (s == null || !c.floatingMenus || (!pc && !c.tracking)) return false;
        if (InputHandler.isVrScreen(s)) return false;                       // our own settings stay touch/mouse-friendly
        if (pc) {                                                           // PC mode: mouse = head, no gyro needed
            boolean title = s instanceof TitleScreen || mc.player == null;
            return title ? c.vrMode == 1 : (c.vrMode == 1 || c.vrMode == 2);
        }
        if (!GyroReceiver.I.isActive()) return false;                       // no head data -> normal screen
        if (s instanceof TitleScreen || mc.player == null) return c.vrMode == 1 && GyroReceiver.I.menuPoseActive();
        return (c.vrMode == 1 || c.vrMode == 2) && GyroReceiver.I.hasHead();
    }

    /** Old name, still used by the panorama hooks / settings text. */
    public static boolean wanted() {
        VrConfig c = VrConfig.I;
        return c.floatingMenus && c.vrMode == 1;
    }

    public static boolean wantedFor(Screen s) { return eligible(Minecraft.getInstance(), s); }

    /** True while an open screen is a floating panel in a world: the world behind keeps following your head. */
    public static boolean tracksWorld(Minecraft mc) {
        Screen s = ScreenCompat.current(mc);
        return s != null && mc.player != null && active && s == screen;
    }

    // ---------- head ----------

    private static float wrap(float d) {
        while (d > 180f) d -= 360f;
        while (d < -180f) d += 360f;
        return d;
    }

    private static float clampf(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    /** Basis vectors for yaw Y (right +) and pitch P (down +): x right, y up, z forward. */
    private static void basis(float yDeg, float pDeg, float[] r, float[] u, float[] f) {
        double y = Math.toRadians(yDeg), p = Math.toRadians(pDeg);
        double sy = Math.sin(y), cy = Math.cos(y), sp = Math.sin(p), cp = Math.cos(p);
        f[0] = (float) (sy * cp); f[1] = (float) -sp; f[2] = (float) (cy * cp);
        r[0] = (float) cy;        r[1] = 0f;          r[2] = (float) -sy;
        u[0] = (float) (sy * sp); u[1] = (float) cp;  u[2] = (float) (cy * sp);
    }

    private static float dot(float[] a, float[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

    private static float vfov(Minecraft mc) {
        try {
            Object opt = Refl.call(mc.options, "fov");
            Object v = Refl.call(opt, "get");
            if (v instanceof Number n) return clampf(n.floatValue(), 30f, 110f);
        } catch (Throwable ignored) { }
        return 70f;
    }

    // ---------- per frame ----------

    /** Render thread, start of every frame (or once per tick if the render hook is missing). */
    public static void frame(Minecraft mc) {
        Screen cur = ScreenCompat.current(mc);
        if (cur == null || !eligible(mc, cur) || !initRefl(mc)) {
            if (cur != screen) { screen = null; haveAnchor = false; }
            releaseCursor(cur);
            active = false;
            problem = cur == null ? "" : (problem.isEmpty() ? "off for this screen" : problem);
            keepPanorama(mc);
            return;
        }
        GyroReceiver g = GyroReceiver.I;
        boolean menuPose = cur instanceof TitleScreen || mc.player == null;
        boolean pc = PcMode.active();
        float hy, hp;
        if (pc) {
            pcHead(mc, cur, cur != screen, menuPose);
            hy = pcYaw;
            hp = pcPitch;
        } else {
            hy = menuPose ? wrap(g.menuYaw()) : g.yawDeg();
            hp = menuPose ? g.menuPitch() : g.pitchDeg();
        }

        if (cur != screen || !haveAnchor) {                     // new screen: put the panel where you look
            screen = cur;
            haveAnchor = true;
            anchorYaw = hy;
            anchorPitch = clampf(hp, -15f, 25f);
            ringA = 0f;
        }
        // leash: drag the panel if you turn too far from it
        float ry = wrap(hy - anchorYaw), rp = hp - anchorPitch;
        if (ry > LEASH_YAW) anchorYaw += ry - LEASH_YAW;
        else if (ry < -LEASH_YAW) anchorYaw += ry + LEASH_YAW;
        if (rp > LEASH_PITCH) anchorPitch += rp - LEASH_PITCH;
        else if (rp < -LEASH_PITCH) anchorPitch += rp + LEASH_PITCH;
        anchorPitch = clampf(anchorPitch, -70f, 70f);

        float W = cur.width, H = cur.height;
        float F = (H * 0.5f) / (float) Math.tan(Math.toRadians(vfov(mc) * 0.5));   // focal length in GUI px
        float k = VrConfig.I.menuScale / F;                                        // world units per GUI px (panel at distance 1)

        float[] pr = new float[3], pu = new float[3], pf = new float[3];
        float[] cr = new float[3], cu = new float[3], cf = new float[3];
        basis(anchorYaw, anchorPitch, pr, pu, pf);
        basis(hy, hp, cr, cu, cf);

        float facing = dot(cf, pf);
        if (facing < MIN_FACING) { active = false; return; }
        float t = 1f / facing;
        float gu = t * dot(cf, pr), gv = t * dot(cf, pu);
        gx = W * 0.5f + gu / k;
        gy = H * 0.5f - gv / k;

        // projection of panel pixels around the gaze point (exact projection, then linearised)
        float[] a = project(gx, gy, W, H, k, F, pr, pu, pf, cr, cu, cf);
        float[] b = project(gx + 1f, gy, W, H, k, F, pr, pu, pf, cr, cu, cf);
        float[] d = project(gx, gy + 1f, W, H, k, F, pr, pu, pf, cr, cu, cf);
        if (a == null || b == null || d == null) { active = false; return; }
        M[0] = b[0] - a[0]; M[2] = b[1] - a[1];       // d(screen)/d(panel x)
        M[1] = d[0] - a[0]; M[3] = d[1] - a[1];       // d(screen)/d(panel y)
        M[4] = a[0] - (M[0] * gx + M[1] * gy);
        M[5] = a[1] - (M[2] * gx + M[3] * gy);
        active = true;
        problem = "";

        setPointer(mc, gx, gy);
        keepPanorama(mc);
    }

    /** Panel pixel -> screen pixel (GUI units), or null if it is behind you. */
    private static float[] project(float px, float py, float W, float H, float k, float F,
                                   float[] pr, float[] pu, float[] pf, float[] cr, float[] cu, float[] cf) {
        float u = (px - W * 0.5f) * k, v = -(py - H * 0.5f) * k;
        float wx = pf[0] + u * pr[0] + v * pu[0];
        float wy = pf[1] + u * pr[1] + v * pu[1];
        float wz = pf[2] + u * pr[2] + v * pu[2];
        float zc = wx * cf[0] + wy * cf[1] + wz * cf[2];
        if (zc < 0.05f) return null;
        float xc = wx * cr[0] + wy * cr[1] + wz * cr[2];
        float yc = wx * cu[0] + wy * cu[1] + wz * cu[2];
        return new float[]{W * 0.5f + F * xc / zc, H * 0.5f - F * yc / zc};
    }

    // ---------- PC mode: the mouse is the head ----------

    private static float pcYaw, pcPitch;
    private static boolean pcSeen, cursorOff;
    private static double lastRX, lastRY, wroteX = Double.NaN, wroteY = Double.NaN;
    private static Method mHandle;

    /** Mouse movement turns a virtual head. The OS cursor is hidden/locked while the panel is up. */
    private static void pcHead(Minecraft mc, Screen cur, boolean newScreen, boolean menuPose) {
        if (newScreen) {
            if (menuPose) { if (!(cur instanceof TitleScreen) || !pcInit) { pcYaw = 0f; pcPitch = 0f; } }
            else if (mc.player != null) { pcYaw = mc.player.getYRot(); pcPitch = mc.player.getXRot(); }
            pcInit = true;
            pcSeen = false;
        }
        lockCursor(mc);
        try {
            double rx = fXpos.getDouble(mc.mouseHandler), ry = fYpos.getDouble(mc.mouseHandler);
            if (rx != wroteX || ry != wroteY) {                 // Minecraft got a new real cursor position
                if (pcSeen) {
                    float s = VrConfig.I.pcSens;
                    pcYaw += (float) (rx - lastRX) * s;
                    pcPitch = clampf(pcPitch + (float) (ry - lastRY) * s, -89f, 89f);
                }
                lastRX = rx;
                lastRY = ry;
                pcSeen = true;
            }
        } catch (Throwable t) {
            problem = "missing mouse access";
            fXpos = null;
        }
        // the world behind the panel follows the virtual head too
        if (!menuPose && mc.player != null) {
            mc.player.setYRot(pcYaw);
            mc.player.setXRot(pcPitch);
            GyroReceiver.setOld(mc.player, pcYaw, pcPitch);
        }
    }

    private static boolean pcInit;

    private static long windowHandle(Minecraft mc) {
        try {
            Object win = mWin.invoke(mc);
            if (mHandle == null) {
                for (String n : new String[]{"handle", "getWindow"}) {
                    try {
                        Method m = win.getClass().getMethod(n);
                        if (m.getReturnType() == long.class) { mHandle = m; break; }
                    } catch (NoSuchMethodException ignored) { }
                }
            }
            return mHandle == null ? 0L : ((Number) mHandle.invoke(win)).longValue();
        } catch (Throwable t) {
            return 0L;
        }
    }

    /** Disabled cursor = endless relative mouse movement, no visible OS pointer (PC only, never on a phone). */
    private static void lockCursor(Minecraft mc) {
        long h = windowHandle(mc);
        if (h == 0L) return;
        try {
            org.lwjgl.glfw.GLFW.glfwSetInputMode(h, org.lwjgl.glfw.GLFW.GLFW_CURSOR, org.lwjgl.glfw.GLFW.GLFW_CURSOR_DISABLED);
            cursorOff = true;
        } catch (Throwable ignored) { }
    }

    /** Panel went away while a screen is still open (e.g. VR settings): give the normal cursor back. */
    private static void releaseCursor(Screen cur) {
        if (!cursorOff) return;
        cursorOff = false;
        pcSeen = false;
        if (cur == null) return;                  // screen closed: Minecraft grabs the mouse itself
        try {
            long h = windowHandle(Minecraft.getInstance());
            if (h != 0L) org.lwjgl.glfw.GLFW.glfwSetInputMode(h, org.lwjgl.glfw.GLFW.GLFW_CURSOR, org.lwjgl.glfw.GLFW.GLFW_CURSOR_NORMAL);
        } catch (Throwable ignored) { }
    }

    // ---------- the mouse follows the crosshair ----------

    private static boolean reflOk;

    private static boolean initRefl(Minecraft mc) {
        if (reflTried) return reflOk && fXpos != null;
        reflTried = true;
        try {
            Object mh = mc.mouseHandler;
            for (Class<?> k = mh.getClass(); k != null && fXpos == null; k = k.getSuperclass()) {
                try { fXpos = k.getDeclaredField("xpos"); fYpos = k.getDeclaredField("ypos"); } catch (NoSuchFieldException ignored) { }
            }
            if (fXpos != null) { fXpos.setAccessible(true); fYpos.setAccessible(true); }
            mWin = Minecraft.class.getMethod("getWindow");
            Object win = mWin.invoke(mc);
            mGetScreenW = win.getClass().getMethod("getScreenWidth");
            mGetScreenH = win.getClass().getMethod("getScreenHeight");
            mGetGuiW = win.getClass().getMethod("getGuiScaledWidth");
            mGetGuiH = win.getClass().getMethod("getGuiScaledHeight");
        } catch (Throwable t) {
            CardboardVrClient.LOG.warn("Floating menu: could not reach the mouse position / window size", t);
            fXpos = null;
        }
        reflOk = fXpos != null && mGetGuiW != null;
        if (!reflOk) problem = "missing mouse/window access";
        return reflOk;
    }

    private static void setPointer(Minecraft mc, float guiX, float guiY) {
        try {
            Object win = mWin.invoke(mc);
            double sw = ((Number) mGetScreenW.invoke(win)).doubleValue(), sh = ((Number) mGetScreenH.invoke(win)).doubleValue();
            double gw = ((Number) mGetGuiW.invoke(win)).doubleValue(), gh = ((Number) mGetGuiH.invoke(win)).doubleValue();
            if (gw < 1 || gh < 1) return;
            wroteX = guiX * sw / gw;
            wroteY = guiY * sh / gh;
            fXpos.setDouble(mc.mouseHandler, wroteX);
            fYpos.setDouble(mc.mouseHandler, wroteY);
        } catch (Throwable t) {
            problem = "missing mouse access";
            fXpos = null;
        }
    }

    // ---------- drawing hooks (ScreenDrawMixin) ----------

    private static Matrix3x2fStack pose(GuiGraphicsExtractor g) {
        try {
            if (mPose == null) mPose = g.getClass().getMethod("pose");
            Object o = mPose.invoke(g);
            return o instanceof Matrix3x2fStack st ? st : null;
        } catch (Throwable t) {
            if (problem.isEmpty()) problem = "missing pose matrix";
            return null;
        }
    }

    /** Start of the screen drawing: from here on everything is drawn on the floating panel. */
    public static void begin(Screen s, GuiGraphicsExtractor g) {
        if (s != screen || !active) return;
        if (nest++ > 0) return;                                  // already inside the panel (outer hook pushed it)
        Matrix3x2fStack st = pose(g);
        if (st == null) { active = false; nest = 0; return; }
        st.pushMatrix();
        st.mul(new Matrix3x2f(M[0], M[2], M[1], M[3], M[4], M[5]));
    }

    /** End of the screen drawing: pop the panel, then draw the crosshair in plain screen space. */
    public static void end(Screen s, GuiGraphicsExtractor g) {
        if (nest == 0 || s != screen) return;
        if (--nest > 0) return;                                  // an inner hook ended; the outer one is still open
        Matrix3x2fStack st = pose(g);
        if (st != null) st.popMatrix();
        drawCrosshair(s, g);
    }

    /** Wrapped backgrounds (dim, blur, panorama) must stay full-screen: drop the panel matrix while they draw. */
    public static void bgBegin(GuiGraphicsExtractor g) {
        if (nest == 0) return;
        Matrix3x2fStack st = pose(g);
        if (st == null) return;
        st.pushMatrix();
        st.identity();
        bgDepth++;
    }

    public static void bgEnd(GuiGraphicsExtractor g) {
        if (bgDepth == 0) return;
        Matrix3x2fStack st = pose(g);
        if (st != null) st.popMatrix();
        bgDepth--;
    }

    /** In a world the pause/inventory background (dim + blur) is skipped so you can see the world around the panel. */
    public static boolean hideBackground(Screen s) {
        return active && s == screen && Minecraft.getInstance().player != null && !(s instanceof TitleScreen);
    }

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (a >>> 24) & 255, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return (Math.round(aa + (ba - aa) * t) << 24) | (Math.round(ar + (br - ar) * t) << 16)
                | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }

    private static void drawCrosshair(Screen s, GuiGraphicsExtractor g) {
        drawHits++;
        long now = System.nanoTime();
        float dt = lastDrawNs == 0 ? 0.016f : Math.min(0.1f, (now - lastDrawNs) / 1.0e9f);
        lastDrawNs = now;
        float k = 1f - (float) Math.exp(-dt * 14.0);
        boolean over = false;
        for (var ch : s.children()) {
            if (ch instanceof AbstractWidget w && (!w.active || !w.visible)) continue;
            if (ch.isMouseOver(gx, gy)) { over = true; break; }
        }
        ringA += ((over ? 1f : 0f) - ringA) * k;
        double t = now / 1.0e9;
        int cx = s.width / 2, cy = s.height / 2;
        float a = ringA;
        float ro = 2.5f + a * 5.5f + (float) Math.sin(t * 6.0) * 0.4f * a;
        float ri = a * (ro - 2.0f);
        disc(g, cx, cy, ro + 1f, ri > 0.2f ? ri - 1f : 0f, 0x99000000);
        disc(g, cx, cy, ro, ri, lerp(0xF0FFFFFF, 0xF08affc0, a));
    }

    /** Filled disc (inner radius 0) or ring, drawn as horizontal spans. */
    private static void disc(GuiGraphicsExtractor g, int cx, int cy, float ro, float ri, int argb) {
        int r = (int) Math.ceil(ro);
        for (int dy = -r; dy <= r; dy++) {
            float o2 = ro * ro - dy * dy;
            if (o2 < 0f) continue;
            int xo = (int) Math.floor(Math.sqrt(o2));
            if (ri > 0f && Math.abs(dy) < ri) {
                int xi = (int) Math.ceil(Math.sqrt(ri * ri - dy * dy));
                if (xi > xo) continue;
                g.fill(cx - xo, cy + dy, cx - xi + 1, cy + dy + 1, argb);
                g.fill(cx + xi, cy + dy, cx + xo + 1, cy + dy + 1, argb);
            } else {
                g.fill(cx - xo, cy + dy, cx + xo + 1, cy + dy + 1, argb);
            }
        }
    }

    // ---------- panorama (3D background on the title screen) ----------

    public static boolean panoActive(Minecraft mc) {
        return wanted() && mc.player == null && (PcMode.active() ? active : GyroReceiver.I.menuPoseActive());
    }

    private static float menuYawNow() { return PcMode.active() ? pcYaw : GyroReceiver.I.menuYaw(); }
    private static float menuPitchNow() { return PcMode.active() ? pcPitch : GyroReceiver.I.menuPitch(); }

    public static float panoYaw(float vanilla) {
        Minecraft mc = Minecraft.getInstance();
        if (!panoActive(mc)) return vanilla;
        panoHitMs = System.currentTimeMillis();
        float y = menuYawNow();
        return VrConfig.I.panoInvertYaw ? -y : y;
    }

    public static float panoPitch(float vanilla) {
        Minecraft mc = Minecraft.getInstance();
        if (!panoActive(mc)) return vanilla;
        float p = menuPitchNow();
        return VrConfig.I.panoInvertPitch ? -p : p;
    }

    /** Fallback if the CubeMap hook does not match: turn the title panorama (yaw only) through its own spin value. */
    private static void keepPanorama(Minecraft mc) {
        if (!(ScreenCompat.current(mc) instanceof TitleScreen ts)) return;
        if (panoObj == null && spinF == null) findPano(mc, ts);
        if (spinF != null && panoObj != null && panoActive(mc) && System.currentTimeMillis() - panoHitMs > 1000) {
            try {
                float yaw = menuYawNow();
                spinF.setFloat(panoObj, -(VrConfig.I.panoInvertYaw ? -yaw : yaw) * 10f);
                panoFallbackMs = System.currentTimeMillis();
            } catch (Throwable ignored) {
                spinF = null;
            }
        }
    }

    public static String panoStatus() {
        if (!wanted()) return "Needs VR mode ON";
        if (!PcMode.active() && !GyroReceiver.I.isActive()) return "Panorama: no gyro";
        long now = System.currentTimeMillis();
        if (now - panoHitMs < 1500) return "Panorama: tracked";
        if (now - panoFallbackMs < 1500) return "Panorama: yaw only";
        return "Panorama: waiting";
    }

    public static String attachStatus() {
        if (!problem.isEmpty() && !active) return "Panel: " + problem;
        if (active) return "Panel: floating, drawn " + (drawHits > 0 ? "YES" : "not yet");
        return "Panel: shows when a menu is open";
    }

    private static void findPano(Minecraft mc, Screen s) {
        panoObj = null;
        spinF = null;
        try {
            Object[] holders = {s, mc.gameRenderer, mc};
            for (Object h : holders) {
                if (h == null || panoObj != null) continue;
                for (Class<?> k = h.getClass(); k != null && k != Object.class && panoObj == null; k = k.getSuperclass()) {
                    for (Field f : k.getDeclaredFields()) {
                        if (f.getType().getSimpleName().equals("PanoramaRenderer")) {
                            f.setAccessible(true);
                            panoObj = f.get(h);
                            break;
                        }
                    }
                }
            }
            if (panoObj != null) {
                for (Class<?> k = panoObj.getClass(); k != null && k != Object.class && spinF == null; k = k.getSuperclass()) {
                    for (Field f : k.getDeclaredFields()) {
                        if (f.getName().equals("spin") && f.getType() == float.class) {
                            f.setAccessible(true);
                            spinF = f;
                            break;
                        }
                    }
                }
            }
        } catch (Throwable t) {
            panoObj = null;
            spinF = null;
        }
        if (!logged) {
            logged = true;
            CardboardVrClient.LOG.info("Floating menu ready (panorama object: {})", panoObj != null);
        }
    }
}
